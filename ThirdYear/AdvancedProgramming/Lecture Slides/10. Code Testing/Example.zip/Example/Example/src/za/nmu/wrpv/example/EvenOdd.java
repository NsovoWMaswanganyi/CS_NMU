package za.nmu.wrpv.example;

public interface EvenOdd {
    int getEven();
    int getOdd();
}
