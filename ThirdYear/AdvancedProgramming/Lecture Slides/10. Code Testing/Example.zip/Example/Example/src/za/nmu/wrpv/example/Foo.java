package za.nmu.wrpv.example;

public class Foo implements EvenOdd {
    public int getEven() {
        return 2;
    }

    public int getOdd() {
        return 1;
    }
}
