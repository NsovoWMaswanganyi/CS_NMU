package za.nmu.wrpv.example;

/**
 * Dummy class to hold integers and demonstrate testing concepts
 */
public class Integers {
    private int[] numbers;
    private int size;
    private int maxSize;

    /**
     * Initialises the class to hold a number of integers and sets
     * the number of initial numbers held to 0
     *
     * @param maxSize maximum number of numbers to store
     *                (Precondition: maxSize > 0)
     */
    public Integers(int maxSize) {
        size = 0;
        numbers = new int[maxSize];
        this.maxSize = maxSize;
    }

    /**
     * Return the contents of the object as a string, often displayed for
     * information purposes
     *
     * @return the contents of the object as a string
     */
    @Override
    public String toString() {
        String contents = "[";
        for (int i = 0; i < size; i++) {
            contents = contents.concat("" + numbers[i]);
            if (i < size - 1)
                contents = contents.concat(", ");
        }
        contents = contents.concat("]");

        return contents;
    }

    /**
     * Adds an integer to the number list
     *
     * @param n (Precondition: size <= maxSize)
     */
    public void add(int n) {
        numbers[size] = n;
        size++;
    }

    /**
     * Adds multiple integers to the number list at once shot
     * @param n Variable number of integers to add
     */
    public void add(int... n) {
        for(int i = 0; i < n.length; i++)
            add(n[i]);
    }

    /**
     * Calculates the average of the number added and returns it.
     *
     * @return the average of the numbers that have been added
     */
    public float average() {
        int total = 0;
        for (int i = 1; i < maxSize; i++)
            total += numbers[i];
        return total / size;
    }

    /**
     * Returns a number that has been previously added
     *
     * @param index the index of the number to be returned
     * @return the integer at position index
     * (Precondition: the index is a valid index)
     */
    public int getNumber(int index) {
        return numbers[index];
    }

    public int[] getInts() {
        return numbers;
    }

    /**
     * Returns the number of integers that have been added
     *
     * @return the number of integers stored
     */
    public int getSize() {
        return size;
    }

    /**
     * Used to demonstrate how to test a method using a mock
     * object. If <i>doesn't</i> work as expected, who is at
     * fault, this object or evenOdd?
     *
     * @param evenOdd Object used to supply an even number
     */
    public void addEven(EvenOdd evenOdd) {
        add(evenOdd.getEven());
    }
}
