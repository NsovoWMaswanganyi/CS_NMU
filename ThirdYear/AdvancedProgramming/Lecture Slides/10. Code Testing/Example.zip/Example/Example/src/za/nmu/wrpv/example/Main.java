package za.nmu.wrpv.example;

import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class Main {

    /**
     * Main entry point of project.
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        testerObject();
        //testCoverage();
        //testLogger();
        //testAsserts();
    }

    /**
     * Simple test to manipulate an object, produce output and
     * examine the output.
     */
    private static void testerObject() {
        // Create object to test
        Integers tester = new Integers(10);

        // Manipulate the data structure
        tester.add(4);
        tester.add(7);
        tester.add(1);

        // Log the output
        System.out.println(tester.toString());

        // ... then "eyeball" the output to determine if correct
    }

    /**
     * A test designed to ensure that all the paths of execution
     * through an object have been taken. Need to check boundary
     * conditions
     */
    private static void testCoverage() {
        // Create object to test
        Integers tester = new Integers(3);

        // Boundaries - depends on size, so need to check empty, middle & full
        System.out.println("Empty = " + tester);

        for (int i = 1; i <= 3; i++) {
            tester.add(i);
            System.out.println("Size " + tester.getSize() + " = " + tester);
        }

        // Need to check path through if statement (although done already in this case)
        // i.e. were the commas in the correct place?
    }

    /**
     * Instead of logging information to screen, rather log to a
     * file, which can be checked again at a later date.
     */
    private static void testLogger() throws Exception {
        // Obtain a logger (in this case a globally accessible log)
        Logger log = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

        // If want to save log file to a specific file
        FileHandler fout = new FileHandler("log.xml");
        // Attach file to logger
        log.addHandler(fout);
        // Specify formatting (XML by default so that can be
        // run through a tool).
        boolean xmlFormat = true;
        if (!xmlFormat) {
            // Simple formatter simply displays output as text (like IntelliJ console).
            SimpleFormatter formatter = new SimpleFormatter();
            fout.setFormatter(formatter);
        }

        // Determine how much information should be logged (will
        // be switched off in final version)
        log.setLevel(Level.ALL);

        // Log some information
        log.info("Running testLogger() method.");

        // Warning (not fatal)
        log.log(Level.WARNING, "Intruder alert!");
        log.warning("Air-lock breached!");

        // Darn! something when VERY wrong
        log.severe("The computer is on fire!! Run!!");
    }

    /**
     * <p>
     * Use assertions to ensure certain things are ACTUALLY
     * true, i.e. not just an assumption. In order to use the assert statement,
     * the virtual machine has to have it switched on. By default it not on,
     * and is not compiled... i.e. test using asserts switched on, when happy
     * switch off asserts and then not compiled into code.
     * </p>
     *
     * <p>
     *     To switch assertions on/off, choose Run -> Edit Configurations, then
     *     in VM Options, type -enableassertions
     * </p>
     */
    private static void testAsserts() {
        Integers integers = new Integers(3);

        // Assert that output produced for empty Integers is correct
        assert integers.toString().equals("[]");

        // Assert single integer set is displayed correctly
        integers.add(1);
        assert integers.toString().equals("[1]");

        // Assert what output for 2 integers will look like
        integers.add(2);
        assert integers.toString().equals("[1, 2]");
    }
}
