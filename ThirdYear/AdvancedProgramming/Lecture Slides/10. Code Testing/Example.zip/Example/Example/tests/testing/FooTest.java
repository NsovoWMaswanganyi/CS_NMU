package testing;

import org.junit.jupiter.api.*;
import za.nmu.wrpv.example.Foo;

import static org.junit.jupiter.api.Assertions.*;

class FooTest {
    private Foo foo;

    @BeforeEach
    void setUp() {
        foo = new Foo();
    }

    @Test
    void getEven() {
        assertTrue((foo.getEven() % 2) == 0,
                "Expected an even number, but an odd one was returned instead.");
    }

    @Test
    void getOdd() {
        assertFalse((foo.getOdd() % 2) == 0,
                "Expected an odd number, but an even number was returned.");
    }

    @Test
    void testEvenAndOdd() {
        assertEquals(2, foo.getEven());
    }
}