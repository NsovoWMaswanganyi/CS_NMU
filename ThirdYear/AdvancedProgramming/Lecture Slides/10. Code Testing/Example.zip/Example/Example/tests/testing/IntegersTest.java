package testing;

import org.junit.jupiter.api.Test;
import za.nmu.wrpv.example.EvenOdd;
import za.nmu.wrpv.example.Integers;

import static org.junit.jupiter.api.Assertions.*;

class IntegersTest {

    @Test
    void testToString() {
        Integers ints = new Integers(3);

        assertEquals("[]", ints.toString());

        ints.add(1);
        assertEquals("[1]", ints.toString());

        ints.add(2);
        assertEquals("[1, 2]", ints.toString());

        ints.add(3);
        assertEquals("[1, 2, 3]", ints.toString());
    }

    @Test
    void add() {
        Integers ints = new Integers(3);

        assertArrayEquals(new int[] {0, 0, 0}, ints.getInts());

        ints.add(1);
        assertArrayEquals(new int[] {1, 0, 0}, ints.getInts());

        ints.add(2);
        assertArrayEquals(new int[] {1, 2, 0}, ints.getInts());

        ints.add(3);
        assertArrayEquals(new int[] {1, 2, 3}, ints.getInts());

        assertThrows(Exception.class, () -> ints.add(4));
    }

    @Test
    void addMultiple() {
        Integers ints = new Integers(4);

        assertArrayEquals(new int[] {0, 0, 0, 0}, ints.getInts());

        ints.add(1, 2);
        assertArrayEquals(new int[] {1, 2, 0, 0}, ints.getInts());

        assertThrows(Exception.class, () -> ints.add(3, 4, 5));
        assertArrayEquals(new int[] {1, 2, 3, 4}, ints.getInts());
    }

    @Test
    void addEven() {
        Integers ints = new Integers(3);

        // Mock object
        EvenOdd evenOdd = new EvenOdd() {
            @Override
            public int getEven() {
                return 4;
            }

            @Override
            public int getOdd() {
                return 3;
            }
        };

        ints.addEven(evenOdd);
        assertArrayEquals(new int[] {4, 0, 0}, ints.getInts());
    }
}