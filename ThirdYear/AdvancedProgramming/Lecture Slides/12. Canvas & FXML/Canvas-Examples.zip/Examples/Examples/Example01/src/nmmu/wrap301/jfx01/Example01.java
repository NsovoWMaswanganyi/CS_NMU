package nmmu.wrap301.jfx01;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.shape.ArcType;
import javafx.stage.Stage;

public class Example01 extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Example 1");
        Group root = new Group();

        // create a canvas on which to draw
        Canvas canvas = new Canvas(300, 250);
        // obtain the context, which allows you to draw on the canvas
        GraphicsContext gc = canvas.getGraphicsContext2D();
        // draw something using the graphics context
        drawShapes(gc);

        // need to add the canvas to a container, so can be added to the scene
        root.getChildren().add(canvas);

        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }

    private void drawShapes(GraphicsContext gc) {
        // determines the colour to be used when filling a shape
        gc.setFill(Color.GREEN);

        // determines the colour of lines and outlines
        gc.setStroke(Color.BLUE);
        // determines how width the line should be
        gc.setLineWidth(5);

        // a straight line
        gc.strokeLine(40, 10, 10, 40);

        // two different types of ovals
        gc.fillOval(10, 60, 30, 30);
        gc.strokeOval(60, 60, 30, 30);

        // two different types of rectangles
        gc.fillRoundRect(110, 60, 30, 30, 10, 10);
        gc.strokeRoundRect(160, 60, 30, 30, 10, 10);

        // different ways of drawing arcs of a circle
        gc.fillArc(10, 110, 30, 30, 45, 240, ArcType.OPEN);
        gc.fillArc(60, 110, 30, 30, 45, 240, ArcType.CHORD);
        gc.fillArc(110, 110, 30, 30, 45, 240, ArcType.ROUND);
        gc.strokeArc(10, 160, 30, 30, 45, 240, ArcType.OPEN);
        gc.strokeArc(60, 160, 30, 30, 45, 240, ArcType.CHORD);
        gc.strokeArc(110, 160, 30, 30, 45, 240, ArcType.ROUND);

        // a polyline is a number of lines, where the end of the one line is the beginning of the next
        // polylines can be filled using different algorithms
        gc.fillPolygon(new double[]{10, 40, 10, 40},
                new double[]{210, 210, 240, 240}, 4);
        gc.strokePolygon(new double[]{60, 90, 60, 90},
                new double[]{210, 210, 240, 240}, 4);
        gc.strokePolyline(new double[]{110, 140, 110, 140},
                new double[]{210, 210, 240, 240}, 4);
    }
}
