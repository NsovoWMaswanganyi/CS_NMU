package nmmu.wrap301.jfx02;

import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.input.MouseButton;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;

public class Controller {
    // the image onto which this controller will paint
    private Canvas canvas = null;

    // remember the stage - need it to link to open/save chooser
    private Stage stage = null;

    // stores the list of shapes drawn (if don't want to save as an image)
    // allows individual lines, points, etc. to be modified (although not done in this example)
    private ArrayList<ShapeData> shapes = new ArrayList<ShapeData>();

    // the current shape being drawn, in this example "line" or "oval"
    // note: a more appropriate data structure to use is an enumeration. For more details, see:
    //          https://docs.oracle.com/javase/tutorial/java/javaOO/enum.html
    private String drawingShape = "line";

    // shape busy drawing
    private ShapeData shape = null;

    public void linkToUI(Stage stage, Scene scene) {
        // remember the stage
        this.stage = stage;

        // obtain controls
        canvas = (Canvas) scene.lookup("#canvas");

        Button btnLoad = (Button) scene.lookup("#load");
        Button btnSave = (Button) scene.lookup("#save");
        Button btnLine = (Button) scene.lookup("#line");
        Button btnOval = (Button) scene.lookup("#oval");

        // set up behaviour for the buttons
        btnLoad.setOnAction(event -> load());
        btnSave.setOnAction(event -> save());
        btnLine.setOnAction(event -> drawingShape = "line");
        btnOval.setOnAction(event -> drawingShape = "oval");

        // set up the event handlers to actually allow shapes (line / oval) to be drawn
        // based on drag-start (starts drawing the shape), drag-move (expands the shape),
        // and drag-stop (shape added to the shapes array)
        canvas.setOnMousePressed(event -> {
            // start drawing if left mouse button
            if (event.getButton() == MouseButton.PRIMARY) {
                // start a new shape
                shape = new ShapeData();

                // remember current (x,y)
                shape.x = event.getX();
                shape.y = event.getY();

                shape.width = 0;
                shape.height = 0;

                // what is being drawn??
                shape.shape = drawingShape;
            }
        });

        canvas.setOnMouseDragged(event -> {
            // if dragging with left mouse AND busy drwaing a shape
            if ((shape != null) && (event.getButton() == MouseButton.PRIMARY)) {
                // update the width and height
                shape.width = event.getX() - shape.x;
                shape.height = event.getY() - shape.y;

                // redraw the screen
                drawShapes();
            }
        });

        canvas.setOnMouseReleased(event -> {
            // if was busy dragging a shape AND released the left mouse button
            if ((shape != null) && (event.getButton() == MouseButton.PRIMARY)) {
                // complete shape
                shape.width = event.getX() - shape.x;
                shape.height = event.getY() - shape.y;

                // add to shapes
                shapes.add(shape);

                // stop drawing
                shape = null;

                // redraw
                drawShapes();
            }
        });
    }

    private void load() {
        // create a file chooser that opens *.shapes files
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Shapes File");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Shapes", "*.shapes"));

        // display the chooser and return the file selected
        File selectedFile = fileChooser.showOpenDialog(stage);

        // if a file was chosen (the user didn't press cancel)
        if (selectedFile != null) {
            try {
                // load shapes
                FileInputStream fin = new FileInputStream(selectedFile);
                ObjectInputStream ois = new ObjectInputStream(fin);
                shapes = (ArrayList<ShapeData>) ois.readObject();
                ois.close();

                // redraw the shapes
                drawShapes();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void save() {
        // create a file chooser that opens *.shapes files
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Shapes File");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Shapes", "*.shapes"));

        // display the chooser and return the file selected
        File selectedFile = fileChooser.showSaveDialog(stage);

        // if a file was chosen (the user didn't press cancel)
        if (selectedFile != null) {
            try {
                // save shapes
                FileOutputStream fout = new FileOutputStream(selectedFile);
                ObjectOutputStream oos = new ObjectOutputStream(fout);
                oos.writeObject(shapes);
                oos.close();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void drawShapes() {
        GraphicsContext gc = canvas.getGraphicsContext2D();


        // setup graphics context
        gc.setStroke(Color.BLUE);
        gc.setLineWidth(3);

        // clears the canvas to white
        gc.setFill(Color.WHITE);
        gc.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());

        // draws all the shapes on the canvas
        for (ShapeData shapeData : shapes) {
            if (shapeData.shape.equals("line")) {
                // draw a line (uses (x1, y1) -> (x2, y2))
                gc.strokeLine(shapeData.x, shapeData.y,
                        shapeData.x + shapeData.width, shapeData.y + shapeData.height);
            } else if (shapeData.shape.equals("oval")) {
                // draw an oval (uses (x, y) & (width, height))
                gc.strokeOval(shapeData.getLeft(), shapeData.getTop(), shapeData.getWidth(), shapeData.getHeight());
            }
        }

        // draw shape busy with (if there is one)
        if (shape != null) {
            // draw bounding box
            gc.setStroke(Color.DARKGRAY);
            gc.strokeRect(shape.getLeft(), shape.getTop(), shape.getWidth(), shape.getHeight());

            // draw it in black
            gc.setStroke(Color.BLACK);

            if (shape.shape.equals("line")) {
                // draw a line (uses (x1, y1) -> (x2, y2))
                gc.strokeLine(shape.x, shape.y,
                        shape.x + shape.width, shape.y + shape.height);
            } else if (shape.shape.equals("oval")) {
                // draw an oval (uses (x, y) & (width, height))
                gc.strokeOval(shape.getLeft(), shape.getTop(), shape.getWidth(), shape.getHeight());
            }
        }
    }
}
