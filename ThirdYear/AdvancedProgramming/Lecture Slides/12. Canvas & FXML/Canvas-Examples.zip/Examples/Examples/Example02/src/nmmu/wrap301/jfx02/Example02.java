package nmmu.wrap301.jfx02;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Button;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

public class Example02 extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    public Scene createScene() {
        BorderPane borderPane = new BorderPane();

        // add some buttons
        FlowPane flowPane = new FlowPane();
        Button btnLine = new Button("Line");
        btnLine.setId("line");
        Button btnOval = new Button("Oval");
        btnOval.setId("oval");
        Button btnLoad = new Button("Load");
        btnLoad.setId("load");
        Button btnSave = new Button("Save");
        btnSave.setId("save");
        flowPane.getChildren().addAll(
                btnLoad,
                btnSave,
                btnLine,
                btnOval
        );

        // create the drawing area
        Canvas canvas = new Canvas(500, 500);
        canvas.setId("canvas");

        borderPane.setTop(flowPane);
        borderPane.setCenter(canvas);

        return new Scene(borderPane);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("Example 2");

        Scene scene = createScene();
        Controller controller = new Controller();
        controller.linkToUI(primaryStage, scene);

        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
