package nmmu.wrap301.jfx02;

import java.io.Serializable;

public class ShapeData implements Serializable {
    // either "line" or "oval"
    public String shape;

    public double x, y, width, height;

    public ShapeData() {}

    public ShapeData(String shape, double x, double y, double width, double height) {
        this.shape = shape;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public double getLeft() {
        if(width >= 0)
            return x;
        else
            return x + width;
    }

    public double getTop() {
        if(height >= 0)
            return y;
        else
            return y + height;
    }

    public double getWidth() {
        return Math.abs(width);
    }

    public double getHeight() {
        return Math.abs(height);
    }
}
