package nmmu.wrap301;

public class Main {
    public static void main(String[] args) {
        // Create a stack that can contain Strings (and/or descendants).
        Stack<String> strStack = new Stack<String>();
        strStack.push("Java");
        strStack.push("is");
        strStack.push("great");

        /*
        The following line won't compile due to type checking:
        */
         strStack.push(10);
        /*
        If you wanted to push a number (or some other object) onto this stack,
        you would need to convert it to a string first - e.g. using the toString
        method.
        */
        strStack.push("" + 10); // String concatenation converts to string.
        strStack.push(new Double(10.5).toString()); // Call toString on an object.

        System.out.printf("String stack is of size %d and contents = %s.\n", strStack.size(), strStack);
        String topString = strStack.pop();
        System.out.printf("The topmost value of the string stack is '%s'.\n", topString);
        System.out.printf("String stack after popping = %s.\n", strStack);

        // Create a stack that can contains Integers
        Stack<Integer> intStack = new Stack<Integer>();
        intStack.push(10);
        intStack.push(11);
        intStack.push(12);
        intStack.push(13);

        /*
        The following line won't compile due to type checking:
        */
         intStack.push("hello");

        System.out.printf("Integer stack is of size %d and contents = %s.\n", intStack.size(), intStack);
        int topInt = intStack.pop();
        System.out.printf("The topmost value of the Integer stack is %d.\n", topInt);
    }
}
