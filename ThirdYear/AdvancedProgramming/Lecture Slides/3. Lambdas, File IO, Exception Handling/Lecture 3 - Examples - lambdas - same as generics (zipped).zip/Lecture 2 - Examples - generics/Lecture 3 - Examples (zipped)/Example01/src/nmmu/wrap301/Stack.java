package nmmu.wrap301;

/**
 * A simple generic stack data structure class.
 * @param <T> The type of data value to be stored in the stack.
 */
public class Stack<T> {
    /**
     * Inner class used only by the stack. The type of value stored is
     * T - as defined in the outer class.
     */
    protected class Node {
        public T value;
        public Node prev;

        public Node(T value, Node prev) {
            this.value = value;
            this.prev = prev;
        }
    }

    // Topmost node of the stack.
    private Node top = null;

    /**
     * Push a value (of type T) onto the top of the stack.
     * @param value The value being pushed.
     */
    public void push(T value) {
        top = new Node(value, top);
    }

    /**
     * Pops the topmost value off the stack.
     * @return The value at the top of the stack. Null is returned if the stack is empty.
     */
    public T pop() {
        if (top == null)
            return null;
        else {
            Node temp = top;
            top = top.prev;
            return temp.value;
        }
    }

    /**
     * Returns the number of value on the stack.
     * @return The number of values on the stack.
     */
    public int size() {
        int count = 0;

        for(Node temp = top; temp != null; temp = temp.prev, count++);

        return count;
    }

    @Override
    public String toString() {
        String s = "-> ";
        Node temp = top;

        while (temp != null) {
            s = s.concat(temp.value.toString());
            temp = temp.prev;
            if (temp != null)
                s = s.concat(" - ");
        }

        return s;
    }
}
