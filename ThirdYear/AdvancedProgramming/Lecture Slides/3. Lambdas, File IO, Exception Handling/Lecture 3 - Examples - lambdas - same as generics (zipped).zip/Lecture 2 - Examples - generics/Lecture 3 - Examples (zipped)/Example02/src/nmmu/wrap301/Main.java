package nmmu.wrap301;

import java.util.IntSummaryStatistics;

public class Main {

    /**
     * Generates a collection of (Integer, V) pairs from a variable length list of parameters.
     * @param values The values to be added to the new pairings.
     * @param <V> The type of the pair value.
     * @return A pairs collection containing a collection of incrementally numbered pairs.
     */
    public static <V> Pairs<Integer, V> generate(V... values) {
        // Create a new collection of pairs, where the key is of type Integer and the values are of unknown type.
        Pairs<Integer, V> pairs = new Pairs<>();

        Integer i = 0;
        // For every value passed in as a parameter
        for (V value : values) {
            // Create a key, value pair
            pairs.set(i, value);
            i++;
        }

        return pairs;
    }

    public static void main(String[] args) {
        // Int -> String pairs
        Pairs<Integer, String> pairs = new Pairs<>();
        pairs.set(1, "one");
        pairs.set(2, "two");
        pairs.set(3, "three");
        pairs.set(1, "ONE");
        System.out.println("pairs = " + pairs);

        // Note: no type casting needed!
        String value = pairs.get(1, "Unknown");
        System.out.println("value = " + value);

        value = pairs.get(10, "Unknown");
        System.out.println("value = " + value);

        // Using the static method.
        Pairs<Integer, Integer> fibs = generate(1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144);
        System.out.println("pairs = " + fibs);
        Integer f = fibs.get(10, -1);
        System.out.printf("f(10) = %d\n", f);
    }
}
