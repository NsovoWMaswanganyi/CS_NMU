package nmmu.wrap301;

// The functional interface annotation is not strictly required, but recommended,
// just like @override. Considered a sanity check!
@FunctionalInterface
public interface Example {
    int count(int x);
}
