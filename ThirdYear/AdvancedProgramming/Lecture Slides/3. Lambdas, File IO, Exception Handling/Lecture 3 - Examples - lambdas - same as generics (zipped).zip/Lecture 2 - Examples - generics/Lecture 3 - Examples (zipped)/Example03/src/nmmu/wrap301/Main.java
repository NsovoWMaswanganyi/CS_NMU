package nmmu.wrap301;

public class Main {
    public static void main(String[] args) {
        // Create people object.
        People people = new People();

        // Add some dummy data to it.
        people.add(new Person("Doe", "Jane", 17));
        people.add(new Person("Doe", "John", 21));
        people.add(new Person("Zee", "Jay", 45));
        people.add(new Person("Jay", "Dee", 30));
        people.add(new Person("Bee", "Jyujyu", 16));
        people.add(new Person("Duud", "Ald", 90));

        /* Selecting items to display using built in methods (not scalable!) */
        System.out.println("Starts with D (built-in)");
        people.displaySurnameStartsWithD();
        System.out.println();

        System.out.println("Younger than 25 (built-in)");
        people.displayYoungerThan25();
        System.out.println();

        System.out.println("Starts with D & younger than 25 (built-in)");
        people.displayYoungerThan25AndSurnameStartsWithD();
        System.out.println();

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Display selected people using an anonymous class - more scalable than built-in
        // just SO verbose for one method!
        System.out.println("Starts with D (anonymous)");
        people.display(new PersonSelector() {
            @Override
            public boolean isSelected(Person person) {
                return person.getSurname().startsWith("D");
            }
        });
        System.out.println();

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Display selected people using a named local class - even MORE verbose
        class SelectYoungerThan25 implements PersonSelector {
            @Override
            public boolean isSelected(Person person) {
                return person.getAge() < 25;
            }
        };

        // In this case can extend the named local class, since HAS a name
        // these classes ONLY exists within the main method, i.e. they cannot
        // be instantiated in another method.
        class SelectStartsWithDAndYoungerThan25 extends SelectYoungerThan25 {
            @Override
            public boolean isSelected(Person person) {
                return super.isSelected(person) && person.getSurname().startsWith("D");
            }
        }

        System.out.println("Younger than 25 and starts with D (named local class)");
        people.display(new SelectStartsWithDAndYoungerThan25());
        System.out.println();

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Display selected people using a lambda expression.
        System.out.println("Younger than 25 (lambda)");
        people.display(person -> person.getAge() < 25);
        System.out.println();

        // Combine selectors - since 1st class, can be assigned as values.
        PersonSelector selName = person -> person.getSurname().startsWith("D");
        PersonSelector selAge = person -> person.getAge() < 25;

        System.out.println("Starts with D & younger than 25 (lambda)");
        people.display(person -> selName.isSelected(person) && selAge.isSelected(person));
        System.out.println();

        // A lambda with a multi-instruction body.
        // Note the use of RETURN (not needed before).
        Example x = (n) -> {
            int count = 0;
            for(int i = 2; i <= n/2; i++)
                if((n % i) == 0)
                    count++;
            return count;
        };

        System.out.println("number of factors = " + x.count(100));
    }
}
