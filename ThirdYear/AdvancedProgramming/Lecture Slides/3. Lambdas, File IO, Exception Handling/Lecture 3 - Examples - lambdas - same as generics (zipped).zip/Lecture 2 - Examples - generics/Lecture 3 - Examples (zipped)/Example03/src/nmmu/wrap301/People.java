package nmmu.wrap301;

import java.util.ArrayList;

public class People {
    private ArrayList<Person> people;

    public People() {
        people = new ArrayList<>();
    }

    public void add(Person person) {
        people.add(person);
    }

    public void displayYoungerThan25() {
        for(Person person : people)
            if(person.getAge() < 25)
                System.out.println(person);
    }

    public void displaySurnameStartsWithD() {
        for(Person person : people)
            if(person.getSurname().startsWith("D"))
                System.out.println(person);
    }

    public void displayYoungerThan25AndSurnameStartsWithD() {
        for(Person person : people)
            if((person.getAge() < 25) && (person.getSurname().startsWith("D")))
                System.out.println(person);
    }

    /**
     * General purpose display method that accepts a selector method.
     * If the selector returns true for a specific person, that person
     * will be display.
     * @param selector Functional Interface that returns true if a specific person must be displayed.
     */
    public void display(PersonSelector selector) {
        for(Person person : people)
            if(selector.isSelected(person))
                System.out.println(person);
    }
}
