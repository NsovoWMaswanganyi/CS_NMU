package nmmu.wrap301;

@FunctionalInterface
public interface PersonSelector {
    boolean isSelected(Person person);
}
