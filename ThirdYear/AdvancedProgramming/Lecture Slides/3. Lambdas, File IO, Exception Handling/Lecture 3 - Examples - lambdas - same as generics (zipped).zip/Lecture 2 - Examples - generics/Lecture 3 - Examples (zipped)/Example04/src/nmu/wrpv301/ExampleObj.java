package nmu.wrpv301;

public class ExampleObj {
    private String name;

    public ExampleObj(String name) {
        this.name = name;
    }

    public void f(int a) {
        System.out.printf("%s.f(%d) called...\n", name, a);
    }

    public void g(int b) {
        System.out.printf("%s.g(%d) called...\n", name, b);
    }

    public void h(int c) {
        System.out.printf("%s.h(%d) called...\n", name, c);
    }

    public static void staticCall(int n) {
        System.out.printf("ExampleObj.staticCall(%d) called...\n", n);
    }
}
