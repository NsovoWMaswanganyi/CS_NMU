package nmu.wrpv301;

@FunctionalInterface
public interface IFunc {
    void call(int n);
}
