package nmu.wrpv301;

@FunctionalInterface
public interface IFuncObj {
    void call(ExampleObj obj, int n);
}
