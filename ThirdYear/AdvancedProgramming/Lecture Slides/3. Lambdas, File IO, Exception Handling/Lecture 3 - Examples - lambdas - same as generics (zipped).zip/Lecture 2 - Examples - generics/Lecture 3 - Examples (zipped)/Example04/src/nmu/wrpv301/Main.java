package nmu.wrpv301;

public class Main {
    public static void main(String[] args) {
        // Create objects.
        ExampleObj a = new ExampleObj("a");
        ExampleObj b = new ExampleObj("b");
        ExampleObj c = new ExampleObj("c");

        // Call object instance methods directly.
        System.out.println("Call object instance methods directly...");
        a.f(1);
        b.g(2);
        c.h(3);
        System.out.println();

        // Call static method directly.
        System.out.println("Call static method directly...");
        ExampleObj.staticCall(4);
        System.out.println();

        // Assign object instance methods to variables.
        IFunc i = n -> a.f(n);
        IFunc j = b::g;
        IFunc k = ExampleObj::staticCall;

        // Call methods from variables.
        System.out.println("Call object instance method from variables...");
        i.call(5);
        j.call(6);
        k.call(7);
        System.out.println();

        // Assign general method call to variables, i.e. call the SAME
        // method on DIFFERENT objects.
        IFuncObj i2 = (obj, n) -> obj.h(n);
        IFuncObj j2 = ExampleObj::g;

        // Call same method on different objects.
        System.out.println("Call same method on different objects...");
        System.out.println("Call h(8) on different objects...");
        i2.call(a, 8);
        i2.call(b, 8);

        System.out.println("Call g(9) on different objects...");
        j2.call(a, 9);
        j2.call(b, 9);
    }
}
