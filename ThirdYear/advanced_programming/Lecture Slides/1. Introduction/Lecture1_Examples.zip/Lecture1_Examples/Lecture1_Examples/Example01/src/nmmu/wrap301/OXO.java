package nmmu.wrap301;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class OXO extends JFrame implements ActionListener {
    private Label lblResult;
    private Vector btns;
    private boolean gameStarted;
    private int turn;

    public static void main(String[] args) {
        OXO prac = new OXO();
    }

    public OXO() {
        // create vector to hold JButtons
        btns = new Vector(9);
        setBounds(100, 100, 200, 250);
        buildUI();
        //pack();
        setTitle("nmmu.wrap301.OXO");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        gameStarted = false;
        turn = 0; // nobody's turn
        setVisible(true);
    }

    public void buildUI() {
        setLayout(new BorderLayout());
        add("South", lblResult = new Label("Game not started!"));

        JPanel pnlJButtons = new JPanel();
        pnlJButtons.setLayout(new GridLayout(3, 3));

        for (int i = 0; i < 9; i++) {
            JButton aBtn = new JButton();
            aBtn.setBackground(Color.lightGray);
            btns.add(aBtn);
            pnlJButtons.add(aBtn);
            aBtn.addActionListener(this);
        }

        add("Center", pnlJButtons);
    }

    private int getPlayer(int row, int col) {
        int index = row * 3 + col;
        JButton btn = (JButton) btns.get(index);

        if (btn.getText() == "X") {
            return 1;
        } else if (btn.getText() == "O") {
            return 2;
        } else {
            return 0;
        }
    }

    public void actionPerformed(ActionEvent ev) {
        JButton btnClicked = (JButton) ev.getSource();
        int btnIndex = btns.indexOf(btnClicked);

        if (!gameStarted) {
            // start game by clearing JButtons/grid
            gameStarted = true;

            // clear all JButtons
            for (int i = 0; i < 9; i++) {
                JButton aBtn = (JButton) btns.get(i);
                aBtn.setText("");
                aBtn.setBackground(Color.lightGray);
            }

            turn = 1; // player 1's turn (X)

            lblResult.setText("Game started: X's turn");
        } else {
            // check if can place mark, then place it and change turns
            if (btnClicked.getText() == "") {
                if (turn == 1) {
                    btnClicked.setText("X");
                    btnClicked.setBackground(Color.yellow);
                    lblResult.setText("Player 2's turn");
                    turn = 2;
                } else {
                    btnClicked.setText("O");
                    btnClicked.setBackground(Color.cyan);
                    lblResult.setText("Player 1's turn");
                    turn = 1;
                }
            } else {
                lblResult.setText("Cannot place mark there!");
            }

            // check for win or draw
            int winner = 0; // no winner
            // check rows
            for (int row = 0; row < 3; row++) {
                if ((getPlayer(row, 0) == getPlayer(row, 1)) && (getPlayer(row, 1) == getPlayer(row, 2)) &&
                        (getPlayer(row, 0) != 0)) {
                    winner = getPlayer(row, 0);
                }
            }

            // check columns
            for (int col = 0; col < 3; col++) {
                if ((getPlayer(0, col) == getPlayer(1, col)) && (getPlayer(1, col) == getPlayer(2, col)) &&
                        (getPlayer(0, col) != 0)) {
                    winner = getPlayer(0, col);
                }
            }

            //check top-left to bottom-right diagonal
            if ((getPlayer(0, 0) == getPlayer(1, 1)) && (getPlayer(1, 1) == getPlayer(2, 2)) &&
                    (getPlayer(0, 0) != 0)) {
                winner = getPlayer(0, 0);
            }

            //check top-right to bottom-left diagonal
            if ((getPlayer(2, 0) == getPlayer(1, 1)) && (getPlayer(1, 1) == getPlayer(0, 2)) &&
                    (getPlayer(2, 0) != 0)) {
                winner = getPlayer(2, 0);
            }

            //count number of placed marks
            int count = 0;
            for (int i = 0; i < 9; i++) {
                JButton btn = (JButton) btns.get(i);
                if (btn.getText() == "") {
                    count++;
                }
            }

            if (winner != 0) {
                // there was a winner
                if (winner == 1) {
                    lblResult.setText("Player 1 won!");
                    gameStarted = false;
                    turn = 0;
                } else {
                    lblResult.setText("Player 2 won!");
                    gameStarted = false;
                    turn = 0;
                }
            } else if (count == 0) {
                // draw
                lblResult.setText("Game was a draw!");
                gameStarted = false;
                turn = 0;
            }
        }
    }
}