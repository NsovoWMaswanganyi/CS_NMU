package wrpv301.l01.e02;

import java.util.*;

public class Example02
{
 	public static void main(String []args)
	{
		Random rand = new Random();
		int n = rand.nextInt();
		System.out.println("random int = " + n);
	}
}