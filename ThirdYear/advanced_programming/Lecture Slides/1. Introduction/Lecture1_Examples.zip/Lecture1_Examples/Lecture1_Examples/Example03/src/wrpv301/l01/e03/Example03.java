package wrpv301.l01.e03;

import wrpv301.l01.e03.models.*;

public class Example03 {
    public static void main(String args[]) {
        new Example03();
    }

    public Example03() {
        Person Person1 = new Person();

        Person1.setName("Bob");
        Person1.setAge(36);

        System.out.println(Person1.getName());
        System.out.println(Person1.getAge());
    }
}