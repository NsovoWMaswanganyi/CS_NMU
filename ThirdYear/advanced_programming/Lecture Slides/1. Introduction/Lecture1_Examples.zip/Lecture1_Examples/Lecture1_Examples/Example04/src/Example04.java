public class Example04
{
	public static void main(String args[])
	{
		new Example04();
	}

	public Example04()
	{
		// Create lecturer and student objects.
		Lecturer lecturer = new Lecturer();
		Student student = new Student();

		// Set values of student and lecturer.
		lecturer.setName("Bob");
		lecturer.setAge(36);
		lecturer.setSalary(234.34f);

		student.setName("John");
		student.setAge(20);
		student.setStudentNr(202524586);

		// Use student methods on student object.
		System.out.println(student.getName());
		System.out.println(student.getStudentNr());

		// Assign lecturer to person using polymorphism.
		Person person = lecturer;

		// Use person methods on lecturer object (typed as a person).
		System.out.println(person.getName());
		System.out.println(person.getAge());

		// Typecast back to lecturer.
		Lecturer lecturer2 = (Lecturer) person;
		lecturer2.setSalary(100);

		// Use student as person.
		person = student;

		System.out.println(person.getName());
		System.out.println(person.getAge());
	}
}