public class Lecturer extends Person
{
	private float salary;

	public void setSalary(float salary)
	{
		this.salary = salary;
	}

	public float getSalary()
	{
		return salary;
	}

	@Override
	public void setAge(int age) {
		if(age < 0) return;

		super.setAge(age);
	}
}