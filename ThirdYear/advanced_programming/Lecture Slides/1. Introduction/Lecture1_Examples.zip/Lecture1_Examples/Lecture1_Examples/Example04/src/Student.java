public class Student extends Person
{
	private int studentNr;

	public void setStudentNr(int studentNr)
	{
		this.studentNr = studentNr;
	}

	public float getStudentNr()
	{
		return studentNr;
	}
}