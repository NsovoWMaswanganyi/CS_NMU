public class Example05
{
	public static void main(String args[])
	{
		new Example05();
	}

	public Example05()
	{
		// Parameterised constructors used.
		Lecturer lecturer = new Lecturer("Bob", 36, 234.34f);
		Student student = new Student("John", 20, 202524586);

		// Copy constructor used, i.e. name and age copied, but not student number.
		Person person = new Person(student);
		System.out.println(person.getName());
		System.out.println(person.getAge());

		// Default constructor used, created with initial values "Dummy" and 0.
		Person anotherPerson = new Person();
		System.out.println(anotherPerson.getName());
		System.out.println(anotherPerson.getAge());
	}
}