public class Lecturer extends Person
{
	private float salary;

	public Lecturer()
	{
		super("", 0);
	}

	public Lecturer(String name, int age, float salary)
	{
		super(name, age);
		this.salary = salary;
	}

	public void setSalary(float salary)
	{
		this.salary = salary;
	}

	public float getSalary()
	{
		return salary;
	}
}