public class Person
{
	private String name;
	private int age;

	// Default constructor.
	public Person()
	{
		name = "Dummy";
		age = 0;
	}

	// Parameterised constructor.
	public Person(String name, int age)
	{
		this.name = name;
		this.age = age;
	}

	// Copy constructor.
	public Person(Person person)
	{
		name = person.name;
		age = person.age;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public void setAge(int age)
	{
		this.age = age;
	}

	public String getName()
	{
		return name;
	}

	public int getAge()
	{
		return age;
	}
}