
public class Example06
{

	public static void main(String args[])
	{
		new Example06();
	}

	public Example06()
	{
		Lecturer lecturer1 = new Lecturer("Bob", 40, 234.34f);
		Student student1 = new Student("John", 20, 202524586);

		Person Person1 = lecturer1;

		System.out.println(Person1.getName());
		System.out.println(Person1.getAge());

		Person1 = student1;

		System.out.println(Person1.getName());
		System.out.println(Person1.getAge());
	}
}