

public class Student extends Person
{
	private int studentNr;

	public Student(String name, int age, int studentNr)
	{
		super(name, age);
		this.studentNr = studentNr;
	}

	public void setStudentNr(int studentNr)
	{
		this.studentNr = studentNr;
	}

	public float getStudentNr()
	{
		return studentNr;
	}
}