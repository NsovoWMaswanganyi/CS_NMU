
public class Example07
{

	public static void main(String args[])
	{
		new Example07();
	}

	public Example07()
	{
		// Student can be instantiated - NOT abstract.
		Student bob = new Student("Bob", 17, 98798773);

		System.out.println(bob.getName());
		System.out.println(bob.getAge());

		// Person CANNOT be instantiated, since it is abstract; i.e.
		// Person john = new Person("John", 21);

		// Person is abstract, but CAN still be used as a field type.
		Person person = bob;
		person.setAge(25);

		System.out.println(person.getName());
		System.out.println(person.getAge());
	}
}