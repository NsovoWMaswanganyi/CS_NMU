
public abstract class Person
{
	protected String name;
	protected int age;
	private int phoneNumber;

	public Person(String name, int age)
	{
		this.name = name;
		this.age = age;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public abstract void setAge(int age);

	public abstract String getName();

	public abstract int getAge();

}