

public class Student extends Person
{
	private int studentNr;

	public Student(String name, int age, int studentNr)
	{
		super(name, age);
		this.studentNr = studentNr;
	}

	public String getName()
	{
		return name;
	}

	public int getAge()
	{
		return age;
	}
	
	public void setAge(int age)
	{
		this.age = age;
	}

	public void setStudentNr(int studentNr)
	{
		this.studentNr = studentNr;
	}

	public float getStudentNr()
	{
		return studentNr;
	}
}