public class Demi extends Student implements SalaryPerson
{
	private float salary;

	public Demi(String name, int age, int studentNr, float salary)
	{
		super(name, age, studentNr);
		this.salary = salary;
	}

	@Override
	public void setSalary(float salary)
	{
		this.salary = salary;
	}

	@Override
	public float getSalary()
	{
		return salary;
	}

	// overriding the default implementation of display
	@Override
	public void display() {
		System.out.println("Demi salary = " + getSalary());
	}
}