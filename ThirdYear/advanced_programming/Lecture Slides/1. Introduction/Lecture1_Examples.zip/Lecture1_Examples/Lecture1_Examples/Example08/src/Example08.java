public class Example08
{
	public static void main(String args[])
	{
		new Example08();
	}

 	public Example08()
	{
		// Instantiate different classes.
		Lecturer bob = new Lecturer("Bob", 40, 234.34f);
		Demi sally = new Demi("Sally", 21, 201345434, 192.56f);
		Student john = new Student("John", 20, 202524586);

		// Polymorphic assignment of lecturer to person.
		Person person = bob;
		person.display();

		// Polymorphic assignment of student to person.
		person = john;
		person.display();

		// Assignment of lecturer OR demi to common type (SalaryPerson interface).
		// Use default method, i.e. display
		SalaryPerson salariedPerson = bob;
		salariedPerson.display();

		// Sally is a demi, demi overrode display, so Demi.display used instead
		// of SalaryPerson.display.
		salariedPerson = sally;
		salariedPerson.display();

		// Display current VAT.
		System.out.println("VAT = " + SalaryPerson.VAT);

		// A student is NOT a salaried person, so cannot assign, i.e.
		// salariedPerson = john;
	}
}