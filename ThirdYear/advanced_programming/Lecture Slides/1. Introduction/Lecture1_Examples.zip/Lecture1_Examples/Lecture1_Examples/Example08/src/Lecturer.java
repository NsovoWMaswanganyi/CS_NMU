public class Lecturer implements SalaryPerson {
    private float salary;
    private String name;
    private int age;

    public Lecturer(String name, int age, float salary) {
        this.name = name;
        this.age = age;
        this.salary = salary;
    }

    public void setSalary(float salary) {
        this.salary = salary;
    }

    public float getSalary() {
        return salary;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return "Professor " + name;
    }

    @Override
    public int getAge() {
        return age;
    }

    // NOTE: no implementation of display required because there is a
    // default one already.
}