public interface Person
{
	// No implementation for these methods, so MUST be provided by a class
	// implementing this interface.
	void setName(String name);

	void setAge(int age);

	String getName();

	int getAge();

	// Java language level 8 feature - default method
	// Default method implementation May ONLY use interface methods and other
	// packages to do work. An implementing class MAY provide own version of the
	// method if they want too.
	default void display() {
		System.out.printf("%s (%d)\n", getName(), getAge());
	}
}