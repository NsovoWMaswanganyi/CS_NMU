public interface SalaryPerson extends Person
{
	// No implementation for these methods, so MUST be provided by a class
	// implementing this interface.
	void setSalary(float salary);

	float getSalary();

	// Java language level 8 feature - default method
	// Default method implementation May ONLY use interface methods and other
	// packages to do work. An implementing class MAY provide own version of the
	// method if they want too.
	default void display() {
		System.out.printf("%s (%d), R%.2f\n", getName(), getAge(), getSalary());
	}


	// Constant defined in an interface - i.e. cannot be changed once defined.
	float VAT = 14.0f;
}