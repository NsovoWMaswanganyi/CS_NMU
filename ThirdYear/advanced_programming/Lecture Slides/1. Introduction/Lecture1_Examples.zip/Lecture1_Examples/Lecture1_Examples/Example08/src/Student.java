public class Student implements Person {
    private int studentNr;
    private String name;
    private int age;

    public Student(String name, int age, int studentNr) {
        this.name = name;
        this.age = age;
        this.studentNr = studentNr;
    }

    public void setStudentNr(int studentNr) {
        this.studentNr = studentNr;
    }

    public float getStudentNr() {
        return studentNr;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getAge() {
        return age;
    }
}