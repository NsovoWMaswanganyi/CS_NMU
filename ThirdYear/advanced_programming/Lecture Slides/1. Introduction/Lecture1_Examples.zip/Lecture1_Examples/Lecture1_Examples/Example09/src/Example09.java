public class Example09 {
    public static void main(String[] args) {
        Info dog = new PetInfo(3, "Dogmeat");
        System.out.println(dog);
    }
}
