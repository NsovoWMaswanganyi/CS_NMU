public interface ExtendedInfo extends Info{
    // because extends info, there exists a set/getName and
    // asString (which is changed below).

    void setAge(int age);
    int getAge();

    // provide a NEW default implementation using the "inherited" one
    default String asString() {
        return Info.super.asString() + ", Age = " + getAge();
    }
}
