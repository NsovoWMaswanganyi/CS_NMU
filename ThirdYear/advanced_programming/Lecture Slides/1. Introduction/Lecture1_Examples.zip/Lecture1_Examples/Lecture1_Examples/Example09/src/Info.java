public interface Info {
    void setName(String name);
    String getName();

    // interfaces do NOT normally have implemented methods.
    // a default method can be given, BUT may only use interface methods.
    // a class implementing the interface MAY replace the implementation if they want.
    default String asString() {
        return "Name = " + getName();
    }
}
