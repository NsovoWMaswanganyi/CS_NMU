public class PetInfo implements ExtendedInfo {
    private int age;
    private String name;

    public PetInfo(int age, String name) {
        this.age = age;
        this.name = name;
    }

    /*
    // don't use the default asString implementation, give
    // own version.
    @Override
    public String asString() {
        return "Bob";
    }
    */

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getName() {
        return name;
    }

    // Method called whenever an object is to be converted to a String,
    // such as when displayed using System.out.println
    @Override
    public String toString() {
        // use the default method provided to format the String
        return "toString = [" + asString() + "]";
    }

    @Override
    public String asString() {
        return "sdkjfhsdkjfhsdf";
    }

    @Override
    public void setAge(int age) {

    }

    @Override
    public int getAge() {
        return 0;
    }
}
