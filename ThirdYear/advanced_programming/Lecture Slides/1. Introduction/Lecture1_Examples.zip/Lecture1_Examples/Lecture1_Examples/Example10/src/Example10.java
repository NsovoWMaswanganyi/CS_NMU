public class Example10 {
    public static void main(String[] args) {
        // from Example08 module
        Demi bob = new Demi("Bob", 19, 100, 125.0f);
        bob.display();

        // from Example09.jar
        PetInfo dogmeat = new PetInfo(3, "Dogmeat");
        System.out.println(dogmeat);
    }
}