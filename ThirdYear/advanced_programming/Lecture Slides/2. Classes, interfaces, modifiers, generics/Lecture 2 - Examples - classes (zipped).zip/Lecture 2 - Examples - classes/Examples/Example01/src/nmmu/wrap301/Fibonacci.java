package nmmu.wrap301;

import java.math.BigInteger;

// Class is final, so may not be extended.
public final class Fibonacci {
    /**
     * Static collection of first "sequenceSize" Fibonacci numbers.
     */
    public static BigInteger[] fib;

    /**
     * Number of numbers in the Fibonacci sequence. Final, so cannot be changed.
     */
    public static final int sequenceSize = 101;

    /**
     * Static method to initialise and calculate the first 101 Fibonacci numbers and store in the fib array.
     */
    public static void calculate() {
        // Static method may ONLY access static fields and methods!

        // Allocate enough space to hold 101 numbers, numbered 0..100.
        fib = new BigInteger[sequenceSize];

        // Starting the sequence at zero (not one).
        fib[0] = fib[1] = BigInteger.ONE;

        // Calculate fibonacci sequence.
        for (int n = 2; n < sequenceSize; n++) {
            fib[n] = fib[n - 2].add(fib[n - 1]);
        }
    }

    /**
     * Non-static method to display calculated Fibonacci numbers.
     */
    public void display() {
        // Non-static method MAY access static fields and methods.
        for (int n = 0; n < sequenceSize; n++) {
            System.out.println("fib(" + n + ") = " + fib[n]);
        }
    }
}
