package nmmu.wrap301;

public class Main {
    public static void main(String[] args) {
        // May call calculate, since method is <b>static</b>.
        Fibonacci.calculate();
        System.out.println("Number of Fibonacci numbers = " + Fibonacci.sequenceSize);
        System.out.println("fib(10)=" + Fibonacci.fib[10]);

        /*
        May NOT call: Fibonacci.display(); since method is non-static and requires
        an OBJECT on which to be called.
         */
        Fibonacci f = new Fibonacci();
        // Calculate was already called, so shared .fib has been calculated already
        System.out.println("fib(20)=" + f.fib[20]);
        f.display();
    }
}
