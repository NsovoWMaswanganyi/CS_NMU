package nmmu.wrap301;

import java.util.ArrayList;

public class Invoice {
    public static final float VAT = 0.14f;

    // STATIC means that an invoice entry object is NOT bound to the outer object,
    // i.e. it may be instantiated without the outer object (unlike the stack's node).
    public static class InvoiceEntry {
        private int quantity;
        private String description;
        private float unitCost;

        public InvoiceEntry(int quantity, String description, float unitCost) {
            this.quantity = quantity;
            this.description = description;
            this.unitCost = unitCost;
        }

        public int getQuantity() {
            return quantity;
        }

        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public float getUnitCost() {
            return unitCost;
        }

        public void setUnitCost(float unitCost) {
            this.unitCost = unitCost;
        }

        public float cost() {
            // MAY access static fields and methods from a static class
            float cost = quantity * unitCost * (1 + VAT);
            return Math.round(cost * 100.0f) / 100.0f ;
        }

        @Override
        public String toString() {
            return quantity + " x " + description + " @ R" + unitCost + " + VAT = R" + cost();
        }
    }

    protected ArrayList<InvoiceEntry> entries = new ArrayList<InvoiceEntry>();

    public void add(InvoiceEntry entry) {
        entries.add(entry);
    }

    public InvoiceEntry remove(int index) {
        return entries.remove(index);
    }

    public float total() {
        float total = 0;

        // FOR-EACH entry in entries
        for(InvoiceEntry entry : entries)
            total += entry.cost();

        return total;
    }

    @Override
    public String toString() {
        return entries.toString() + ", total = R" + total();
    }
}
