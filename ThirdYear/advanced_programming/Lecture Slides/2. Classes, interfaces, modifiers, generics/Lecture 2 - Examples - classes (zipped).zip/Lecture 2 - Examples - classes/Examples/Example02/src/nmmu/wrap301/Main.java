package nmmu.wrap301;

public class Main {
    public static void main(String[] args) {
        Stack stack = new Stack();

        /*
        Cannot say "new Stack.Node" as node MUST be inside the
        outer class, i.e. a Node cannot exist without a Stack.
         */

        /*
        FYI integers, strings, booleans converted to objects, which have a
        toString method which is used whenever a String version is required.
         */
        System.out.println("Adding values to stack...");
        stack.push("Hello");
        stack.push("World");
        stack.push(1);
        stack.push(2);
        stack.push(true);

        System.out.println("Displaying values on stack...");
        stack.display();

        System.out.println("Popping values off stack...");
        stack.pop();
        stack.pop();

        System.out.println("Displaying values on stack...");
        stack.display();


        System.out.println("Displaying invoices...");
        Invoice inv1 = new Invoice();
        Invoice inv2 = new Invoice();

        // Entry created independent of a specific invoice object
        Invoice.InvoiceEntry entry = new Invoice.InvoiceEntry(5, "Tex Chocolate Bar", 5.75f);

        // Adding same entry to multiple objects.
        inv1.add(entry);
        inv2.add(entry);
        inv2.add(new Invoice.InvoiceEntry(7, "Smarties", 6.12f));

        System.out.println(inv1);
        System.out.println(inv2);
    }
}
