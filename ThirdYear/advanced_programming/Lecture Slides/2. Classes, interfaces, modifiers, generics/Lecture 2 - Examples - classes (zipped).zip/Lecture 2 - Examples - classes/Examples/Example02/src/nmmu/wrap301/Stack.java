package nmmu.wrap301;

public class Stack {
    /**
     * Named inner class representing a node on the stack. The class
     * may access the outer class (Stack) fields and methods in addition
     * to its own. THIS refers to the node itself (not the Stack).
     */
    protected class Node {
        public Object value = null;
        public Node prev = null;

        public Node(Object value) {
            // This (Node)'s value is set to parameter
            this.value = value;
        }

        /**
         * Push self onto the stack
         */
        public void push() {
            // prev = object field, top = outer class field
            prev = top;

            /*
            This refers to THIS node (not the stack), if you require a reference to the
            stack (outer class), it is Stack.this
             */
            top = this;
        }
    }

    protected Node top = null;

    public void push(Object value) {
        Node newNode = new Node(value);
        newNode.push();
    }

    public Object pop() {
        if(top == null)
            return null;
        else {
            Node oldTop = top;
            top = oldTop.prev;
            return oldTop.value;
        }
    }

    public void display() {
        Node current = top;
        while(current != null) {
            System.out.println(current.value);
            current = current.prev;
        }
    }
}
