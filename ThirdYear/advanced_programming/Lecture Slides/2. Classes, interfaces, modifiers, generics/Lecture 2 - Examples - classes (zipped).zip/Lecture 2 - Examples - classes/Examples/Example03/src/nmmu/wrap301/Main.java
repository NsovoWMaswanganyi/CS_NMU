package nmmu.wrap301;

public class Main {
    public static void display(Person person) {
        System.out.println("Main.display started...");
        person.display();
        System.out.println("Main.display ended...");
    }

    public static void main(String[] args) {
        // Define a new class AND instantiate it, storing a reference to the new object in p
        Person p = new Person() {
            private String name = "unknown";

            @Override
            public void display() {
                System.out.println("Person's name is " + name);
            }

            @Override
            public String getName() {
                return name;
            }

            @Override
            public void setName(String name) {
                this.name = name;
            }
        };

        // Use interface methods defined
        p.setName("Bob");
        p.display();

        // Define AND create an object as passed through as a parameter. Since no reference to it is stored, this
        // object will be disposed of when the method returns. Note, completely different implementation from
        // previous one.
        display(new Person() {
            @Override
            public void display() {
                System.out.println("Another person's name is Sally.");
            }

            @Override
            public String getName() {
                return null;
            }

            @Override
            public void setName(String name) {
            }
        });
        // Pay special attention to brackets.

        // Define a new class that extends an existing class.
        Pet dog = new Pet("Dogmeat") {
            @Override
            public String toString() {
                return super.toString() + " -doggo";
            }
        };

        Person bob = new Person() {
            @Override
            public void display() {

            }

            @Override
            public String getName() {
                return null;
            }

            @Override
            public void setName(String name) {

            }
        };

        System.out.println(dog);
    }
}
