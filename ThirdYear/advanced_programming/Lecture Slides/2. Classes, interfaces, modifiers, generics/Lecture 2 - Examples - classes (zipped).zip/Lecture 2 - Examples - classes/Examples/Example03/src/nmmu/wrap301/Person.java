package nmmu.wrap301;

public interface Person {
    void display();

    String getName();
    void setName(String name);
}
