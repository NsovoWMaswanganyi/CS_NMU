package nmmu.wrap301;

public class Main {
    public static void main(String[] args) throws CloneNotSupportedException {
        // create a new person
        Person bob = new Person("Billy", "Bob");

        // calls toString method when displaying
        System.out.println(bob);

        Person sam = (Person) bob.clone();
        sam.setFirstName("Sam");
        System.out.println(sam);

        // create and display a person collection
        People people = new People();
        people.add("Billy", "Bob");
        people.add("Sam", "Bob");
        people.add("Uncle", "Bob");
        people.add("John", "Doe");
        people.add("Jane", "Doe");

        System.out.println("People");
        System.out.println(people);
        System.out.println();

        // create a deep COPY, modify and display it
        People people2 = (People) people.clone();
        people2.add("Another", "Person");

        System.out.println("People (after clone and modification)");
        System.out.println(people);
        System.out.println();

        System.out.println("People2");
        System.out.println(people2);
        System.out.println();
    }
}
