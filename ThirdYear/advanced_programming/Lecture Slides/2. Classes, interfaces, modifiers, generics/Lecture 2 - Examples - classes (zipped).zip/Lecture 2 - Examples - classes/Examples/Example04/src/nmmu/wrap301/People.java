package nmmu.wrap301;

import java.util.ArrayList;

/**
 * A collection of person objects.
 */
public class People {
    // we will discuss generics soon!
    private ArrayList<Person> people;

    public People() {
        people = new ArrayList<Person>();
    }

    public void add(String firstName, String surname) {
        people.add(new Person(firstName, surname));
    }

    @Override
    public String toString() {
        return people.toString();
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        // need to perform a deep copy, since has complex data

        People temp = new People();

        // clone each contained person to new container
        // this is the FOR-EACH syntax that can be used for collections, it reads FOR-EACH person in the
        // people collection, do something
        for(Person person : people) {
            // create a clone of person
            Person p = (Person) person.clone();
            temp.people.add(p);

            // OR using the copy constructor
            // temp.people.add(new Person(person));
        }

        return temp;
    }
}
