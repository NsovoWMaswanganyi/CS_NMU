package nmmu.wrap301;

public class Person {
    private String surname, firstName;

    public Person(String firstName, String surname) {
        this.surname = surname;
        this.firstName = firstName;
    }

    /**
     * Copy constructor (copies the values of an existing object into a new one).
     * @param person The person being copied.
     */
    public Person(Person person) {
        surname = person.surname;
        firstName = person.firstName;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    // clone is protected by default, can promote to public (can make something more visible, but not
    // less visible). By default, throws an exception, i.e. cannot be cloned.
    // shallow copy, since does not have any other complex objects.
    @Override
    public Object clone() throws CloneNotSupportedException {
        // create a new object and copy the values from this object into it.
        Person temp = new Person(this);
        return temp;
    }

    @Override
    public String toString() {
        return firstName + " " + surname;
    }
}
