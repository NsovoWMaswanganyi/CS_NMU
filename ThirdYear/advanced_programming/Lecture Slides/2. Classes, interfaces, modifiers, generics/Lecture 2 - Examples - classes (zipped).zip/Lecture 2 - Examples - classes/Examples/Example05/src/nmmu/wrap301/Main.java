package nmmu.wrap301;

public class Main {
    public static void main(String[] args) {
        new Main();
    }

    public int sum(int... numbers) {
        int total = 0;

        // FOR-EACH n in the numbers array
        for (int n : numbers) {
            total += n;
        }

        return total;
    }

    public int lengthLargerThan(int minLength, String... strings) {
        int count = 0;

        // Iterating through string array
        for (int i = 0; i < strings.length; i++) {
            if (strings[i].length() > minLength)
                count++;
        }

        return count;
    }

    public Main() {
        // Using the variable length parameter method
        int s = sum(1, 2, 3, 4, 3, 4,3, 4,3, 4,3, 4,3, 4,3, 4,3, 4);
        System.out.println("Sum = " + s);

        int t = lengthLargerThan(3, "abc", "1234", "defghi", "ababababa", "ab");
        System.out.println("Count = " + t);
    }
}
