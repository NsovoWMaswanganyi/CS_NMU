package nmmu.wrap301;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Example00 {
    public static void main(String[] args) {
        // code before try-catch. will be executed
        Scanner sin = new Scanner(System.in);
        System.out.println("Enter two doubles:");

        // code that might produce errors
        try
        {
            // code to try and run, might throw exception(s)
            // will stop immediately if an exception is thrown and will jump to catch block(s)
            Double x = sin.nextDouble(); // user could enter a non-number
            Double y = sin.nextDouble(); // user could enter a non-number
            Double z = x / y; // could attempt to divide by zero
            System.out.println(x + " / " + y + " = " + z);
        }
        catch (InputMismatchException e) {
            // will handle the specific error of the user entering an incorrectly formatted
            // string
            System.out.println("A double was expected, but something else was entered.");
        }
        catch (Exception e)
        {
            // general exception, handles most kinds
            System.out.println("Unable to complete operation. " + e.getClass().getName());
        }
        finally
        {
            // optional finally block. will be executed regardless of whether an exception
            // occured or not
            System.out.println("Finally");
        }

        // code after try-catch. will ONLY be executed if there are no unhandled exceptions
        System.out.println("Completed operation.");
    }
}
