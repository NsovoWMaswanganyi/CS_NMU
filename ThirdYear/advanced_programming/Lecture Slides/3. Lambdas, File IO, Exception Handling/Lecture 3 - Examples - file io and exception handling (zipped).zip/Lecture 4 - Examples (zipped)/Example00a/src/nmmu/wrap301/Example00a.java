package nmmu.wrap301;

public class Example00a
{
	public static void main(String[] args)
	{
		Test t = new Test();		
		try
		{
            // calculate the number of days in a given number of years (leap-years ignored)
			int days = t.YearsToDays(-15);
			System.out.println(days + " days.");
		}
		catch (NegativeNumberException nne)
		{
			System.out.println(nne.getMessage());
            // query the exception for additional information about the exception
            System.out.println("Negative value = " + nne.getNumber());
        }
	}
}