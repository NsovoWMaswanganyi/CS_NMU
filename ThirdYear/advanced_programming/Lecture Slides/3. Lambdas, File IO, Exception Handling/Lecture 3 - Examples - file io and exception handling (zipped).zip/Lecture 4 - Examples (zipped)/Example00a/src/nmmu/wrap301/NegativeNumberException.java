package nmmu.wrap301;

/**
 * A custom exception that is thrown if a non-negative value was expected,
 * but a negative one was obtained instead.
 */
class NegativeNumberException extends Exception {
    // additional information about the exception
    protected int number;

    public NegativeNumberException(int number) {
        super();
        this.number = number;
    }

    public NegativeNumberException(String S, int number) {
        super(S);
        this.number = number;
    }

    public int getNumber() {
        return number;
    }
}
