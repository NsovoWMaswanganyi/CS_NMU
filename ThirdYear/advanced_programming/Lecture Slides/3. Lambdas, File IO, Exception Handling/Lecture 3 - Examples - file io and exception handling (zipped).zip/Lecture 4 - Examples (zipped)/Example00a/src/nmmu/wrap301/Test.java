package nmmu.wrap301;

class Test {
    public int YearsToDays(int years) throws NegativeNumberException {
        if (years >= 0) {
            return years * 365;
        } else {
            // invalid value for years, so throw an exception
            throw new NegativeNumberException("Years should be positive!", years);
        }
    }
}
