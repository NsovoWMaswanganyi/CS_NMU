package nmmu.wrap301;

import java.io.IOException;

class ExGen {
    /**
     * test method
     * @param a throw 'First Error'?
     * @param b rethrow exception?
     * @throws Exception
     */
    public ExGen(boolean a, boolean b) throws Exception {
        System.out.println("Start of ExGen...");

        try {
            System.out.println("Before maybe throw First Error...");
            if(a) {
                System.out.println("Throwing First Error...");
                throw new Exception("First Error");
            } else {
                System.out.println("Did not throw First Error...");
            }
            System.out.println("After maybe throw First Error...");
            
        } catch (IOException e) {
            System.out.println("ExGen (catch IOException) " + e.getMessage());

        } catch (Exception e) {
            System.out.println("ExGen (catch Exception) " + e.getMessage());

            //if(b) throw new IOException("Second Error");
            if (b) throw e;
        } finally {

            System.out.println("ExGen (do finally)");
        }

        System.out.println("End of ExGen...");
    }
}