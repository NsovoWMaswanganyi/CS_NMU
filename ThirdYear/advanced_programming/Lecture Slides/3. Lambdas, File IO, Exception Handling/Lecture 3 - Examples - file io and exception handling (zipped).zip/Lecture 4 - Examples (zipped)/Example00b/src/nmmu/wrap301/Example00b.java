package nmmu.wrap301;

import java.io.*;
import java.util.Scanner;

public class Example00b {
    public static void main(String[] args) {
        new Example00b();
    }

    public Example00b() {
        System.out.println("Start of Example00b...");

        Scanner sin = new Scanner(System.in);
        sin.nextDouble();

        try {
            System.out.println("Start of try...");
            new ExGen(false, true);
            System.out.println("End of try...");

        } catch (IOException e) {
            // caught an IO exception
            System.out.println("Example00b (catch IOException)"+ e.getMessage());

        } catch (Exception e) {
            // fall-through to more general exception handler
            System.out.println("Example00b (catch Exception)"+ e.getMessage());

        } finally {
            System.out.println("Example00b (do finally)");
        }

        System.out.println("End of Example00b...");
    }
}