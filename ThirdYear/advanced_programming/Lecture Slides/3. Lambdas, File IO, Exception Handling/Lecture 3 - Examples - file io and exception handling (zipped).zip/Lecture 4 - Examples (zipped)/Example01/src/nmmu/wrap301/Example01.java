package nmmu.wrap301;
import java.util.Scanner;

public class Example01
{
 	public static void main(String []args)
	{
		// tell the scanner what stream of info to use, in this case the input stream,
		// i.e. keyboard input by default.
		Scanner in = new Scanner(System.in);

		// region Basic text input example.
		String name;
		System.out.println("What is your name?");
		name = in.next();
		System.out.println("Hello " + name);
		// endregion

		// region Basic integer input example
		int age;
		System.out.println("How old are you?");
		age = in.nextInt();
		System.out.println("Wow, that's young :)");
		// consume carriage return after age input - else in this example will not capture the
		// next line as expected
		in.nextLine();
		// endregion

		// region Basic use of delimiter
		// Demonstrate how to "chop up" a string using a scanner
		System.out.println("Enter comma separated numbers:");
		int sum = 0;
		int count = 0;
		String values = in.nextLine();

		// create a new scanner that uses the string as the input stream
		Scanner numberScanner = new Scanner(values); // NB
		numberScanner.useDelimiter(","); // split on commas - can be multiple characters

		while(numberScanner.hasNext()) {
			sum += numberScanner.nextInt();
			count++;
		}

		// Example of printing a formatted string
		System.out.printf("Count = %d, Sum = %d\n", count, sum);
		// endregion
	}
}