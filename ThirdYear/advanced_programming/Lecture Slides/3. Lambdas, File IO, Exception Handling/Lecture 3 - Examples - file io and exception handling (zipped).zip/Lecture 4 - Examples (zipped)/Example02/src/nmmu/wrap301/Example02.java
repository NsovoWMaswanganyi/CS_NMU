package nmmu.wrap301;

import java.io.*;
import java.util.*;

public class Example02 {
	public static void main(String[] args) throws FileNotFoundException {
        // STEP 1: obtain an input stream to the data

        // obtain a reference to resource compiled into the project
        InputStream is = Example02.class.getResourceAsStream("/mary.txt");

        // OR

        // open file - specifying the entire path of where it is found
		// File inFile = new File("C:\\Users\\csadv\\Documents\\Work\\2016\\WRAP301\\lectures\\Lecture04-file io\\Examples\\out\\production\\Example02\\mary.txt");

		// convert to useful form
		Scanner in = new Scanner(is);

        // STEP 2: do something with the data stream
		// read contents
		while (in.hasNext()) {
			String line = in.nextLine();
			System.out.println(line);
		}

        // STEP 3: be polite, close the stream when done!
		// close file
		in.close();
	}
}