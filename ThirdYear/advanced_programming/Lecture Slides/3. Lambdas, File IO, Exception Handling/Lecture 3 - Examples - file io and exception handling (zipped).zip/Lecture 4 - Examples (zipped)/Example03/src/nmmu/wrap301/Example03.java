package nmmu.wrap301;
import java.io.*;

public class Example03
{
 	public static void main(String []args) throws FileNotFoundException
	{
		// create/attach to file to write too
        // using the relative filename will cause it to create the file in
        // the PROJECT root
		File outFile = new File("info.txt");

		// convert to a more useful writer
		PrintWriter out = new PrintWriter(outFile);

		//write data to file
		for(int i=1; i<=10; i++)
			out.println("" + i + " x 5 = " + i*5);
			
		//close file - required!
		out.close();			
	}
}