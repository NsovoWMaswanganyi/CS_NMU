package nmmu.wrap301;
import java.io.*;
import java.util.*;

public class Example04
{
 	public static void main(String []args) throws IOException, ClassNotFoundException
	{
		// create data to save
		Module WRAP301 = new Module("WRAP301");
		WRAP301.add(new Student("Joe", "1234"));
		WRAP301.add(new Student("Sue", "2536"));
		WRAP301.add(new Student("Xola", "9863"));
		WRAP301.add(new Student("Thando", "9852"));
		WRAP301.add(new Student("Clint", "3459"));
		WRAP301.add(new Student("Tasha", "6254"));
		WRAP301.add(new Student("Max", "8451"));

        System.out.println("Displaying WRAP301 details...");
		WRAP301.display();
        System.out.println();

		// save to text file
        System.out.println("Saving WRAP301 details...");
		// obtain file to write too
		File outFile = new File("WRAP301.txt");
		PrintWriter out = new PrintWriter(outFile);
		//write data to file
		WRAP301.write(out);
		//close file
		out.close();

		// load from text file
        System.out.println("\nLoading WRAP301 details...");
		// obtain file to read from
		File inFile = new File("WRAP301.txt");
		Scanner in = new Scanner(inFile);
		//read contents
		Module module = new Module();
		module.read(in);
		//close file
		in.close();

        System.out.println("Displaying WRAP301 details...");
		module.display();
	}
}