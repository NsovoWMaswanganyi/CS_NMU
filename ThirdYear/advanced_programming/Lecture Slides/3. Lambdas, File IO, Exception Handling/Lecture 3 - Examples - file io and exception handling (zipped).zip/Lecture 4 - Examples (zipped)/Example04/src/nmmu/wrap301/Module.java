package nmmu.wrap301;

import java.util.*;
import java.io.*;

public class Module {
    private String moduleCode;
    private Vector<Student> students;

    public Module() {
        students = new Vector<Student>();
    }

    public Module(String moduleCode) {
        this.moduleCode = moduleCode;
        students = new Vector<Student>();
    }

    public void add(Student student) {
        students.add(student);
    }

    public int size() {
        return students.size();
    }

    public Student get(int index) {
        return students.get(index);
    }

    public Student get(String studentNumber) {
        Student student = null;
        for (int i = 0; i < size(); i++)
            if (get(i).getStudentNumber().equals(studentNumber)) student = get(i);
        return student;
    }

    public void display() {
        System.out.println("---------------------------------------------------------");
        System.out.println("Module: " + moduleCode);
        System.out.println("---------------------------------------------------------");
        for (int i = 0; i < size(); i++)
            System.out.println(get(i));
    }

    /**
     * Read the entire contents of a module into this module object.
     * @param in The input stream being read from.
     */
    public void read(Scanner in) {
        // read in the title for this module
        moduleCode = in.nextLine();

        // read in how many student data entries will follow
        int size = Integer.parseInt(in.nextLine());

        students.clear();
        // read in that many students and add to student array
        for (int i = 0; i < size; i++) {
            Student student = new Student();

            // each student knows how to read itself from a stream, so let it
            student.read(in);

            add(student);
        }
    }

    /**
     * Write the contents of the entire module to the output stream
     * @param out The stream being written too.
     */
    public void write(PrintWriter out) {
        // write the title of this module
        out.println(moduleCode);

        // write out how MANY students there are going to be written
        out.println(size());

        // now write out each individual student
        for (int i = 0; i < size(); i++)
            // each student know how to write itself to a stream, so let it
            get(i).write(out);
    }
}