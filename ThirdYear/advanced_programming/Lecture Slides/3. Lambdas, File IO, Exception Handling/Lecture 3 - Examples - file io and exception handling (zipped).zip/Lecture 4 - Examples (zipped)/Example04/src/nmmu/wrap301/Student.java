package nmmu.wrap301;

import java.io.*;
import java.util.*;

public class Student {
    private String name;
    private String studentNumber;

    public Student() {

    }

    public Student(String name, String studentNumber) {
        this.name = name;
        this.studentNumber = studentNumber;
    }

    public String getStudentNumber() {
        return studentNumber;
    }

    public String getName() {
        return name;
    }

    public String toString() {
        return name + " (" + studentNumber + ")";
    }

    /**
     * Read the details for a single student into this object.
     * @param in The input stream being read from
     */
    public void read(Scanner in) {
        name = in.nextLine();
        studentNumber = in.nextLine();
    }

    /**
     * Write the details of this student onto an output stream.
     * @param out The output stream being written too
     */
    public void write(PrintWriter out) {
        out.println(name);
        out.println(studentNumber);
    }
}