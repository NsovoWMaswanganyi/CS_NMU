package nmmu.wrap301;
import java.io.*;

public class Example05
{
 	public static void main(String []args) throws IOException
	{
		String info = "WRAP302";
		
		//write info string to binary file
		OutputStream out = new FileOutputStream("data.bin");
		//convert string to array of bytes
		byte[] data = info.getBytes();
		out.write(data);
		// close file
		out.close();
		
		
		
		//read data string from binary file
		InputStream in = new FileInputStream("data.bin");
		//read array of bytes
		data = new byte[1000];
		int count = in.read(data);
		//convert bytes to string
		info = new String(data, 0, count);
		//close file
		in.close();

		System.out.println("From Binary File: " + info);
	}
}