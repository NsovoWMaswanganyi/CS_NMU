package nmmu.wrap301;
import java.io.*;

public class Example06
{
 	public static void main(String []args) throws IOException, ClassNotFoundException
	{
		// create data to save
		Module WRAP301 = new Module("WRAP301");
		WRAP301.add(new Student("Joe", "1234"));
		WRAP301.add(new Student("Sue", "2536"));
		WRAP301.add(new Student("Xola", "9863"));
		WRAP301.add(new Student("Thando", "9852"));
		WRAP301.add(new Student("Clint", "3459"));
		WRAP301.add(new Student("Tasha", "6254"));
		WRAP301.add(new Student("Max", "8451"));
		WRAP301.display();
		
		// save to object file
		ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("WRAP301.obj"));
		out.writeObject(WRAP301);
		out.close();
		
		// load from object file
		ObjectInputStream in = new ObjectInputStream(new FileInputStream("WRAP301.obj"));
		Module module = (Module)in.readObject();
		in.close();
		
		module.display();
	}
}