package nmmu.wrap301;
import java.util.*;
import java.io.*;

public class Module implements Serializable
{
	private String moduleCode;
	private Vector<Student> students;
	
	public Module(String moduleCode)
	{
		this.moduleCode = moduleCode;
		students = new Vector<Student>();
	}
	
	public void add(Student student)
	{
		students.add(student);
	}
	
	public int size()
	{
		return students.size();
	}
	
	public Student get(int index)
	{
		return students.get(index);
	}
	
	public Student get(String studentNumber)
	{
		Student student = null;
		for(int i=0; i<size(); i++)
			if(get(i).getStudentNumber().equals(studentNumber)) student = get(i);
		return student;
	}
	
	public void display()
	{
		System.out.println("---------------------------------------------------------");
		System.out.println("Module: " + moduleCode);
		System.out.println("---------------------------------------------------------");
		for(int i=0; i<size(); i++)
			System.out.println(get(i));
	}
}