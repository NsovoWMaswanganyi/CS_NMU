package nmmu.wrap301;
import java.io.*;

public class Student implements Serializable
{
	private String name;
	private String studentNumber;
	
	public Student (String name, String studentNumber)
	{
		this.name = name;
		this.studentNumber = studentNumber;
	}
	
	public String getStudentNumber()
	{
		return studentNumber;
	}
	
	public String getName()
	{
		return name;
	}
	
	public String toString()
	{
		return name + " (" + studentNumber + ")";
	}
}