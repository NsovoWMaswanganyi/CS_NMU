package nmmu.wrap301.reflection;

public interface AnotherInterface {
    String str();
}
