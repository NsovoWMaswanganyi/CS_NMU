package nmmu.wrap301.reflection;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class Example01 {
    public static void main(String[] args) throws Exception {
        new Example01();
    }

    public Example01() throws Exception {
        // display the class details about the SomeClass class
        displayClassInfo(SomeClass.class);

        // obtain the class information for a class given a STRING
        Class clazz = Class.forName("nmmu.wrap301.reflection.SomeSubClass");

        // display this class' details
        displayClassInfo(clazz);
    }

    /**
     * Display information about the class passed in as a parameter.
     * @param clazz The class being queried.
     */
    public void displayClassInfo(Class clazz) {
        // display the class' name
        System.out.printf("Class = %s\n", clazz.getName());

        // display the name of the package this class belongs too
        System.out.printf("Package = %s\n", clazz.getPackage().getName());

        // display superclasses of this class
        Class superclazz = clazz.getSuperclass();
        System.out.print("Superclasses = ");
        while(superclazz != null) {
            System.out.print(superclazz.getName() + " <- ");
            superclazz = superclazz.getSuperclass();
        }
        System.out.println();

        // implemented interfaces
        System.out.print("Interfaces = ");
        for(Class i : clazz.getInterfaces()) {
            System.out.print(i.getName() + " ");
        }
        System.out.println();

        // display names of all PUBLIC methods implemented
        System.out.print("Methods = ");
        for(Method method : clazz.getMethods()) {
            System.out.print(method.getName() + " ");
        }
        System.out.println();

        // display names of all PUBLIC fields
        System.out.print("Fields = ");
        for(Field field : clazz.getFields()) {
            System.out.print(field.getName() + " ");
        }
        System.out.println();

        System.out.println();
    }
}
