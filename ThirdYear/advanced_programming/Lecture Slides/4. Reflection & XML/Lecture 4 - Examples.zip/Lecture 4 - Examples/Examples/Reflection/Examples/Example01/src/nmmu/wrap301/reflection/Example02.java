package nmmu.wrap301.reflection;

import java.lang.reflect.Field;

public class Example02 {
    public static void main(String[] args) throws Exception  {
        new Example02();
    }

    public Example02() throws Exception {
        // create a new instance of a class using the class object
        Class clazz = Class.forName("nmmu.wrap301.reflection.SomeSubClass");
        SomeSubClass sscObj = (SomeSubClass) clazz.newInstance();
        System.out.println(sscObj);

        //--------------------------------------------------------------------------------------------------------------
        // instantiate another instance of same class (standard way)
        SomeSubClass sscObj2 = new SomeSubClass();
        sscObj2.sField = "2nd object's value";

        // obtain a field with a given name
        Field sField = clazz.getField("sField");

        // display field's details
        System.out.printf("Field name = %s\n", sField.getName());
        System.out.printf("Field type = %s\n", sField.getType().getName());

        // get a specific instance's value for the field
        // note the get method gets passed an OBJECT
        String s = (String) sField.get(sscObj2);
        System.out.printf("sscObj2.sField = %s\n", s);

        // change the value of the field for a SPECIFIC object
        sField.set(sscObj2, "new value");

        // display both objects
        System.out.printf("sscObj = %s\n", sscObj);
        System.out.printf("sscObj2 = %s\n", sscObj2);
        System.out.println();

        //--------------------------------------------------------------------------------------------------------------
        // obtain private field
        Field iPrivate = clazz.getDeclaredField("iPrivate");

        // display field's details
        System.out.printf("Field name = %s\n", iPrivate.getName());
        System.out.printf("Field type = %s\n", iPrivate.getType().getName());

        // don't EVER do this under normal circumstances!!
        // you better have a VERY good reason for doing this!!
        // make private field accessible for getting and setting
        iPrivate.setAccessible(true);

        // get a specific instance's value for the field
        // note the get method gets passed an OBJECT
        Integer i = (Integer) iPrivate.get(sscObj2);
        System.out.printf("sscObj2.iPrivate = %d\n", i);

        // change the value of the field for a SPECIFIC object
        iPrivate.set(sscObj2, 999);

        // display both objects
        System.out.printf("sscObj = %s\n", sscObj);
        System.out.printf("sscObj2 = %s\n", sscObj2);
        System.out.println();

        //--------------------------------------------------------------------------------------------------------------
        // manipulating static fields
        Field STATIC = clazz.getField("STATIC");
        String st = (String) STATIC.get(null);
        System.out.println("STATIC = " + st);
    }
}
