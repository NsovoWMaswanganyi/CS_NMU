package nmmu.wrap301.reflection;

import java.lang.reflect.Method;

public class Example03 {
    public static void main(String[] args) throws Exception {
        new Example03();
    }

    public Example03() throws Exception {
        // instantiate objects
        SomeSubClass sscObj = new SomeSubClass();
        sscObj.sField = "new string value";

        // obtain a method named "toString" - no parameters
        Method method = SomeSubClass.class.getMethod("toString");

        // call method on a specific object - no parameters
        String s = (String) method.invoke(sscObj);
        System.out.printf("toString() = %s\n", s);

        //--------------------------------------------------------------------------------------------------------------
        // note: 2 methods called str, distinguished by parameters
        Method str = SomeSubClass.class.getMethod("str", int.class);
        s = (String) str.invoke(sscObj, 10);
        System.out.println("str(10) = '" + s + "'");

        //--------------------------------------------------------------------------------------------------------------
        Method staticMethod = SomeSubClass.class.getMethod("staticMethod", int.class, String.class);
        // call static method, remembering that a static method is bound to the class, NOT and object
        staticMethod.invoke(null, 20, "hello");
    }
}
