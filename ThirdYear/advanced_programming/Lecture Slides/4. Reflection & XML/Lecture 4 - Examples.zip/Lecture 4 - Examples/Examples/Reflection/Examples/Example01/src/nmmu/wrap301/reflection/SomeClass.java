package nmmu.wrap301.reflection;

public class SomeClass {
    public String sField = "some value";
    protected Integer iField = 10;
    private Boolean bField = false;

    public void display() {
        System.out.println(toString());
    }

    @Override
    public String toString() {
        String s = String.format("SomeClass: iField = %d, sField = '%s', bField = %b", iField, sField, bField);
        return s;
    }
}
