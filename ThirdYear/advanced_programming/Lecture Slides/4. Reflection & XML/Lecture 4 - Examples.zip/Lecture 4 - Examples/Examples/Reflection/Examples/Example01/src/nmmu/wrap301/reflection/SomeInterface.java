package nmmu.wrap301.reflection;

public interface SomeInterface {
    int f(int x);
}
