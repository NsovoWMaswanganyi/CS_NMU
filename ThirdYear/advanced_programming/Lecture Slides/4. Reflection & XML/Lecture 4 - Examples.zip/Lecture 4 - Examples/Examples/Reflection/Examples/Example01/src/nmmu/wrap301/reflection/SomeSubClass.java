package nmmu.wrap301.reflection;

import java.util.ArrayList;

public class SomeSubClass extends SomeClass implements SomeInterface, AnotherInterface {
    private int iPrivate = -1;

    public static String STATIC = "I am static";

    public ArrayList<String> strings = new ArrayList<String>();

    public SomeSubClass() {
        super();
        sField = "some other value";
    }

    public int f(int x) {
        return 2 * x;
    }

    @Override
    public String toString() {
        String s = String.format("SomeSubClass: iField = %d, sField = '%s', iPrivate = %d, STATIC = %s", iField, sField, iPrivate, STATIC);
        return s;
    }

    @Override
    public String str() {
        return toString();
    }

    public String str(int x) {
        return "x = " + x;
    }

    public static void staticMethod(int x, String s) {
        System.out.println("x = " + x + ", s = " + s);
    }

    protected void someMethod() {
        // blah
    }
}
