package nmmu.wrap301.e01;

import org.w3c.dom.*;
import org.w3c.dom.ls.DOMImplementationLS;
import org.w3c.dom.ls.LSOutput;
import org.w3c.dom.ls.LSSerializer;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class Main {
    public static void main(String[] args) throws Exception {
        // example of how to load and query an XML document
        LoadAndQueryXML();

        // example of how to extract a selection of an existing XML document and add it to a
        // new XML document. the new XML document is then saved.
        CreateAndSaveXML();
    }

    private static void LoadAndQueryXML() throws ParserConfigurationException, SAXException, IOException, XPathExpressionException {
        // create DocumentBuilder to parse XML document
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();

        // load document and parse to create tree
        File fin = new File("items.xml");
        Document doc = builder.parse(fin);

        // create xpath object that will allow document to be queried
        XPathFactory xpFactory = XPathFactory.newInstance();
        XPath path = xpFactory.newXPath();

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        // examples of different queries
        ///////////////////////////////////////////////////////////////////////////////////////////////////

        // query document for the 1st item's quantity
        String result = path.evaluate("/items/item[1]/quantity", doc);
        System.out.println("quantity of product[1] = " + result);

        // query document for the currency of the 2nd item's product price
        result = path.evaluate("/items/item[2]/product/price/@currency", doc);
        System.out.println("currency of product[2] = " + result);

        // query document for the product description of any item of which there are 8
        result = path.evaluate("/items/item[quantity='8']/product/description", doc);
        System.out.println("product having quantity of 8 = " + result);

        // query document for the quantity of any item that has a product description of '4-port Mini Hub'
        result = path.evaluate("/items/item[product/description='4-port Mini Hub']/quantity", doc);
        System.out.println("quantity of '4-port Mini Hub' = " + result);

        // how many products are there? note // = any node with name product
        result = path.evaluate("count(//product)", doc);
        System.out.println("count of products = " + result);

        // how many products are there that have prices specified in ZAR amd the price is less than 30 ZAR?
        result = path.evaluate("count(//product[price/@currency='ZAR' and price < 30])", doc);
        System.out.println("count of products = " + result);
    }

    private static void CreateAndSaveXML() throws Exception {
        // create DocumentBuilder to parse XML document
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();

        // load document and parse to create tree
        File fin = new File("items.xml");
        Document doc = builder.parse(fin);

        // create xpath object that will allow document to be queried
        XPathFactory xpFactory = XPathFactory.newInstance();
        XPath path = xpFactory.newXPath();

        // query the document and save out nodes that match a specified criteria
        // create document
        Document outputDoc = createDoc();
        // create root element and attach to document
        Element results = outputDoc.createElement("results");
        outputDoc.appendChild(results);

        //XPathExpression expr = path.compile("//description/text()");
        //XPathExpression expr = path.compile("//item/*/description/text()");
        //XPathExpression expr = path.compile("//item");
        XPathExpression expr = path.compile("//item[quantity>=8 and product/price/@currency='ZAR']");

        // NODESET means more than one node will be returned by the query
        NodeList resultSet = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
        System.out.println("# nodes returned by query = " + resultSet.getLength());

        // unfortunately, the foreach notation does not work for the result set :(
        // i.e. for(Node node : resultSet)
        for (int i = 0; i < resultSet.getLength(); i++) {
            // attach item to root (if you want to use a node from one tree in another, you need to clone it first
            // as a node cannot belong to more than one tree at a time)
            Node node = resultSet.item(i).cloneNode(true);
            // associate the node with the output document
            outputDoc.adoptNode(node);
            // now allowed to attach the nodes together
            results.appendChild(node);
        }

        // get old root
        saveDoc(outputDoc, "items-output.xml");
    }

    /**
     * Create and return an empty document.
     * @return The document that was created.
     * @throws Exception If something went wrong.
     */
    public static Document createDoc() throws Exception {
        // create DocumentBuilder to parse XML document
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();

        // create empty document
        Document doc = builder.newDocument();

        return doc;
    }

    /**
     * <p>Save the document to a file with the given filename.</p>
     * <p>You will be given the code for this method in a test, so you do not need to memorise it.</p>
     * @param doc The document to save.
     * @param filename The filename of the file to which the document will be saved.
     * @throws Exception If something goes wrong, e.g. invalid filename, not enough space, etc.
     */
    public static void saveDoc(Document doc, String filename) throws Exception {
        // obtain serializer
        DOMImplementation impl = doc.getImplementation();
        DOMImplementationLS implLS = (DOMImplementationLS) impl.getFeature("LS", "3.0");
        LSSerializer ser = implLS.createLSSerializer();
        ser.getDomConfig().setParameter("format-pretty-print", true);

        // create file to save too
        FileOutputStream fout = new FileOutputStream(filename);

        // set encoding options
        LSOutput lsOutput = implLS.createLSOutput();
        lsOutput.setEncoding("UTF-8");

        // tell to save xml output to file
        lsOutput.setByteStream(fout);

        // FINALLY write output
        ser.write(doc, lsOutput);

        // close file
        fout.close();
    }
}