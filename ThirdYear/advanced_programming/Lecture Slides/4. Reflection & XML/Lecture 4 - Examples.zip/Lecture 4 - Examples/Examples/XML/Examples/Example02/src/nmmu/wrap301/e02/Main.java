package nmmu.wrap301.e02;

import org.w3c.dom.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;

public class Main {
    /**
     * A method that displays a specific element (and its children) indented on the console.
     *
     * @param element The element to display.
     * @param depth   The current indentation. Each child will be indented one level more than the parent.
     */
    public static void display(Element element, int depth) {
        // create a string of 'depth' tabs
        String indent = "";
        for (int i = 0; i < depth; i++)
            indent = indent.concat("\t");

        // get the name of the node
        String name = element.getNodeName();

        // display the beginning of the node
        System.out.printf("%sBEGIN(%s)\n", indent, name);

        NodeList nodes = element.getChildNodes();
        // for each node, display it (and children if any)
        for (int i = 0; i < nodes.getLength(); i++) {
            Node node = nodes.item(i);

            // is it a node containing child nodes?
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                // it is, so display the child at depth + 1
                Element childElement = (Element) node;
                display(childElement, depth + 1);

                // does the node contain text?
            } else if (node.getNodeType() == Node.TEXT_NODE) {
                // it does, so get the text and display it in quotes
                Text textNode = (Text) node;
                String data = textNode.getTextContent();
                // the string could contain spaces, new lines or tabs on either side of it, so trim these off
                data = data.trim();
                // anything left of the string? if so, display it
                if (data.length() > 0) System.out.printf("\t%s'%s'\n", indent, data);
            }
        }

        // display end of the node
        System.out.printf("%sEND(%s)\n", indent, name);
    }

    public static void main(String[] args) throws Exception {
        // create DocumentBuilder to parse XML document
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();

        // load document and parse to create tree
        File fin = new File("items.xml");
        Document doc = builder.parse(fin);

        // iterate through tree structure
        Element root = doc.getDocumentElement();
        display(root, 0);

        System.out.println();
        System.out.println();

        // obtain all nodes that have the tag name of 'description' and display them
        NodeList descriptions = root.getElementsByTagName("description");
        for (int i = 0; i < descriptions.getLength(); i++)
            display((Element) descriptions.item(i), 0);

    }
}