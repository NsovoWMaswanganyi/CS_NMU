package nmmu.wrap301.e03;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;
import org.w3c.dom.ls.DOMImplementationLS;
import org.w3c.dom.ls.LSOutput;
import org.w3c.dom.ls.LSSerializer;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.FileOutputStream;

public class Main {
    /**
     * Create an empty document.
     * @return The newly created document.
     * @throws Exception If cannot create the document for some reason.
     */
    public static Document createDoc() throws Exception {
        // create DocumentBuilder to parse XML document
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();

        // create empty document
        Document doc = builder.newDocument();

        return doc;
    }

    /**
     * <p>Save the document to a file with the given filename.</p>
     * <p>You will be given the code for this method in a test, so you do not need to memorise it.</p>
     * @param doc The document to save.
     * @param filename The filename of the file to which the document will be saved.
     * @throws Exception If something goes wrong, e.g. invalid filename, not enough space, etc.
     */
    public static void saveDoc(Document doc, String filename) throws Exception {
        // obtain serializer
        DOMImplementation impl = doc.getImplementation();
        DOMImplementationLS implLS = (DOMImplementationLS) impl.getFeature("LS", "3.0");
        LSSerializer ser = implLS.createLSSerializer();
        ser.getDomConfig().setParameter("format-pretty-print", true);

        // create file to save too
        FileOutputStream fout = new FileOutputStream(filename);

        // set encoding options
        LSOutput lsOutput = implLS.createLSOutput();
        lsOutput.setEncoding("UTF-8");

        // tell to save xml output to file
        lsOutput.setByteStream(fout);

        // FINALLY write output
        ser.write(doc, lsOutput);

        // close file
        fout.close();
    }

    /**
     * <p>Creates, populates and returns an element that simply contains a text node. The element will have the
     * following format: &lt;name&gt;text&lt;/name&gt;</p>
     * @param doc The document to which this element belongs.
     * @param name The tag name for the element.
     * @param text The text contained by the element.
     * @return The newly created element.
     */
    public static Element createTextElement(Document doc, String name, String text) {
        Text textNode = doc.createTextNode(text);
        Element element = doc.createElement(name);
        element.appendChild(textNode);
        return element;
    }

    /**
     * <p>Creates, populates and returns a product element in the form <pre>
     *     &lt;product&gt;
     *          &lt;description&gt;description&lt;/product&gt;
     *          &lt;price&gt;price&lt;/price&gt;
     *     &lt;/product&gt;
     * </pre></p>
     * @param doc The document to which the element belongs.
     * @param description The description of the product.
     * @param price The price of the product.
     * @return The newly created product.
     */
    public static Element createProduct(Document doc, String description, String price) {
        Element product = doc.createElement("product");
        product.appendChild(createTextElement(doc, "description", description));
        product.appendChild(createTextElement(doc, "price", price));
        return product;
    }

    /**
     * <p>Creates, populates and returns an item element. The element will contain a nested
     * product element, as well as a &lt;quantity&gt;quantity&lt;quantity&gt; element.</p>
     * @param doc The document to which the element belongs.
     * @param description The description of the product.
     * @param price The price of the product.
     * @param quantity The number of items of the given product type.
     * @return The newly created item.
     */
    public static Element createItem(Document doc, String description, String price, String quantity) {
        Element item = doc.createElement("item");
        item.appendChild(createProduct(doc, description, price));
        item.appendChild(createTextElement(doc, "quantity", quantity));
        return item;
    }

    /**
     * Creates and returns a document containing a number of items.
     */
    public static Document createItemDocument() throws Exception {
        Document doc = createDoc();

        Element items = doc.createElement("items");
        items.appendChild(createItem(doc, "Caramelo Bears", "5.25", "4"));
        items.appendChild(createItem(doc, "Jelly Tots", "1.24", "1000"));
        items.appendChild(createItem(doc, "Smarties", "2.35", "60"));
        doc.appendChild(items);

        return doc;
    }

    public static void main(String[] args) throws Exception {
        saveDoc(createItemDocument(), "output.xml");
    }
}