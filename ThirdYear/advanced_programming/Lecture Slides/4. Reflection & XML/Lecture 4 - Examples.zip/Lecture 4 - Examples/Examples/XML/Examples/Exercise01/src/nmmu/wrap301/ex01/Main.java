package nmmu.wrap301.ex01;

import org.w3c.dom.Document;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;
import java.io.InputStream;

public class Main {
    public static void main(String[] args) throws Exception {
        // create DocumentBuilder to parse XML document
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();

        // load document and parse to create tree
        InputStream is = Main.class.getResourceAsStream("/study_record.xml");
        Document doc = builder.parse(is);

        // create xpath object that will allow document to be queried
        XPathFactory xpFactory = XPathFactory.newInstance();
        XPath path = xpFactory.newXPath();

        // get student's full name
        String result = path.evaluate("/academic_record/student/name", doc)
                + " "
                + path.evaluate("/academic_record/student/surname", doc);
        System.out.println("student name = " + result);

        // write queries below

        // get degree
        String degree = path.evaluate("/academic_record/student/degree", doc);
        System.out.println("degree = " + degree);

    }
}
