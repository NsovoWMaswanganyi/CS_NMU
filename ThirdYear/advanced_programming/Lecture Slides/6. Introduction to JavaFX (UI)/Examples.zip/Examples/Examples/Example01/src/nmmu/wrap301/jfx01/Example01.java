package nmmu.wrap301.jfx01;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * A very basic JavaFX application in which the GUI is created manually. The
 * {@link javafx.application.Application Application} class that is extended
 * is started running by the launch method. This then calls the start method
 * which sets up the GUI.
 */
public class Example01 extends Application {
    // entry point into the application - same as always
    public static void main(String[] args) {
        // called only once. Starts a JavaFX GUI application running.
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        // called when the JavaFX application is to be set up

        // obtain the main Stage on which this application is running
        // set the title bar to "Example01"
        primaryStage.setTitle("Example01");

        // create a new button to place on the stage
        Button btn = new Button();

        // set the set that will appear on the button
        btn.setText("Say 'Hello World'");

        // specify the code that will be run if the button is clicked
        btn.setOnAction(event -> System.out.println("Hello World"));

        // create another button
        Button btn2 = new Button();
        btn2.setText("Say 'Farewell Cruel World'");
        btn2.setOnAction(event -> System.out.println("Farewell Cruel World!!"));

        // specify how controls (e.g. the button) will be laid out on the stage
        // in this case, they will be laid out vertically
        VBox root = new VBox();

        // add the button to the VBox (which knows how to lay out controls
        // added to it)
        root.getChildren().add(btn);
        root.getChildren().add(btn2);

        // specify to the main stage that the current stage to be displayed in
        // it are described by the root stack pane, which must be of a specific
        // size (300 x 250 pixels).
        primaryStage.setScene(new Scene(root, 300, 250));

        // now then, FINALLY display the GUI
        primaryStage.show();
    }
}