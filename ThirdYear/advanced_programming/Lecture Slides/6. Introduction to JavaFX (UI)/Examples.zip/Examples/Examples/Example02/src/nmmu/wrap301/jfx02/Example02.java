package nmmu.wrap301.jfx02;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.*;
import javafx.stage.Stage;

/**
 * A very basic JavaFX application in which the GUI is created manually. The
 * {@link javafx.application.Application Application} class that is extended
 * is started running by the launch method. This then calls the start method
 * which sets up the GUI.
 */
public class Example02 extends Application {
    // entry point into the application - same as always
    public static void main(String[] args) {
        // called only once. Starts a JavaFX GUI application running.
        launch(args);
    }


    /**
     * Lay out buttons from left to right
     */
    public Scene getHorizontalLayout() {
        // specify how controls (e.g. the button) will be laid out on the stage
        HBox root = new HBox();

        // add the buttons to the pane
        root.getChildren().add(new Button("Start"));
        root.getChildren().add(new Button("Rewind"));
        root.getChildren().add(new Button("Pause"));
        root.getChildren().add(new Button("Play"));
        root.getChildren().add(new Button("Fast Forward"));
        root.getChildren().add(new Button("End"));
        root.getChildren().add(new Button("Stop"));

        return new Scene(root);
    }

    /**
     * Lay out buttons from top to bottom
     */
    public Scene getVerticalLayout() {
        // specify how controls (e.g. the button) will be laid out on the stage
        VBox root = new VBox();

        // create all the buttons to be added to the pane
        Button btnStart = new Button("Start");
        Button btnRewind = new Button("Rewind");
        Button btnPause = new Button("Pause");
        Button btnPlay = new Button("Play");
        Button btnFastForward = new Button("Fast Forward");
        Button btnEnd = new Button("End");
        Button btnStop = new Button("Stop");

        // specify that button's maximum width as very large
        btnStart.setMaxWidth(Double.MAX_VALUE);
        btnRewind.setMaxWidth(Double.MAX_VALUE);
        btnPause.setMaxWidth(Double.MAX_VALUE);
        btnPlay.setMaxWidth(Double.MAX_VALUE);
        btnFastForward.setMaxWidth(Double.MAX_VALUE);
        btnEnd.setMaxWidth(Double.MAX_VALUE);
        btnStop.setMaxWidth(Double.MAX_VALUE);

        // alternate way to add all children in a single instruction
        root.getChildren().addAll(
                btnStart,
                btnRewind,
                btnPause,
                btnPlay,
                btnFastForward,
                btnEnd,
                btnStop
        );

        // want each button to use entire horizontal line, false by default
        root.setFillWidth(true);

        return new Scene(root);
    }

    /**
     * Lay out buttons from left to right with wrapping
     */
    public Scene getFlowLayout() {
        // specify how controls (e.g. the button) will be laid out on the stage
        FlowPane root = new FlowPane(Orientation.HORIZONTAL);

        // add the buttons to the pane
        root.getChildren().add(new Button("Start"));
        root.getChildren().add(new Button("Rewind"));
        root.getChildren().add(new Button("Pause"));
        root.getChildren().add(new Button("Play"));
        root.getChildren().add(new Button("Fast Forward"));
        root.getChildren().add(new Button("End"));
        root.getChildren().add(new Button("Stop"));

        return new Scene(root);
    }

    /**
     * Lay out buttons on top of one another
     */
    public Scene getStackedLayout() {
        // specify how controls (e.g. the button) will be laid out on the stage
        StackPane root = new StackPane();

        // add the buttons to the pane
        root.getChildren().add(new Button("Start"));
        root.getChildren().add(new Button("Rewind"));
        root.getChildren().add(new Button("Pause"));
        root.getChildren().add(new Button("Play"));
        root.getChildren().add(new Button("Fast Forward"));
        root.getChildren().add(new Button("End"));
        root.getChildren().add(new Button("Stop"));

        return new Scene(root);
    }

    /**
     * Lay out buttons around the border
     */
    public Scene getBorderLayout() {
        // specify how controls (e.g. the button) will be laid out on the stage
        BorderPane root = new BorderPane();

        // create all the buttons to be added to the pane
        Button btnStart = new Button("Start");
        Button btnRewind = new Button("Rewind");
        Button btnPause = new Button("Pause");
        Button btnPlay = new Button("Play");
        Button btnFastForward = new Button("Fast Forward");

        // specify that button's maximum width as very large
        btnStart.setMaxWidth(Double.MAX_VALUE);
        btnRewind.setMaxWidth(Double.MAX_VALUE);
        btnPause.setMaxWidth(Double.MAX_VALUE);
        btnPlay.setMaxWidth(Double.MAX_VALUE);
        btnFastForward.setMaxWidth(Double.MAX_VALUE);

        // specify that button's maximum height as very large
        btnStart.setMaxHeight(Double.MAX_VALUE);
        btnRewind.setMaxHeight(Double.MAX_VALUE);
        btnPause.setMaxHeight(Double.MAX_VALUE);
        btnPlay.setMaxHeight(Double.MAX_VALUE);
        btnFastForward.setMaxHeight(Double.MAX_VALUE);

        // add the buttons to the pane
        root.setLeft(btnStart);
        root.setTop(btnRewind);
        root.setRight(btnPause);
        root.setBottom(btnPlay);
        root.setCenter(btnFastForward);

        return new Scene(root);
    }

    /**
     * Lay out buttons in a grid
     */
    public Scene getGridLayout() {
        // specify how controls (e.g. the button) will be laid out on the stage
        GridPane root = new GridPane();

        // specify spacing BETWEEN cells
        root.setHgap(5);
        root.setVgap(10);

        // set padding (spacing INSIDE each cell)
        root.setPadding(new Insets(0, 10, 0, 10));

        // create all the buttons to be added to the pane
        Button btnStart = new Button("Start");
        Button btnRewind = new Button("Rewind");
        Button btnPause = new Button("Pause");
        Button btnPlay = new Button("Play");
        Button btnFastForward = new Button("Fast Forward");
        Button btnEnd = new Button("End");
        Button btnStop = new Button("Stop");
        Button btnHelp = new Button("Help");
        Button btnAbout = new Button("About");

        // specify that button's maximum width as very large
        btnStart.setMaxWidth(Double.MAX_VALUE);
        btnRewind.setMaxWidth(Double.MAX_VALUE);
        btnPause.setMaxWidth(Double.MAX_VALUE);
        btnPlay.setMaxWidth(Double.MAX_VALUE);
        btnFastForward.setMaxWidth(Double.MAX_VALUE);
        btnEnd.setMaxWidth(Double.MAX_VALUE);
        btnStop.setMaxWidth(Double.MAX_VALUE);
        btnHelp.setMaxWidth(Double.MAX_VALUE);
        btnAbout.setMaxWidth(Double.MAX_VALUE);

        // specify that button's maximum height as very large
        btnStart.setMaxHeight(Double.MAX_VALUE);
        btnRewind.setMaxHeight(Double.MAX_VALUE);
        btnPause.setMaxHeight(Double.MAX_VALUE);
        btnPlay.setMaxHeight(Double.MAX_VALUE);
        btnFastForward.setMaxHeight(Double.MAX_VALUE);
        btnEnd.setMaxHeight(Double.MAX_VALUE);
        btnStop.setMaxHeight(Double.MAX_VALUE);
        btnHelp.setMaxWidth(Double.MAX_VALUE);
        btnAbout.setMaxWidth(Double.MAX_VALUE);

        // place buttons in cells
        root.add(btnStart, 0, 0);           // 1st column, 1st row
        root.add(btnRewind, 1, 0);          // 2nd column, 1st row
        root.add(btnPause, 2, 0);           // 3rd column, 1st row

        root.add(btnPlay, 0, 1, 2, 1);      // 1st column, 2nd row, span 2 cells horizontally
        root.add(btnFastForward, 2, 1);     // 3rd column, 2nd row

        root.add(btnEnd, 2, 2, 1, 2);       // 3rd column, 3rd row, spans 2 cells vertically
        root.add(btnStop, 0, 2, 2, 2);      // 1st column, 3rd row, spans 2 cells vertically and horizontally

        root.add(btnHelp, 3, 3);            // 4th column, 4th row
        root.add(btnAbout, 3, 2);           // 4th column, 3rd row

        return new Scene(root);
    }

    /**
     * Lay out buttons in a tiled grid (equal sized nodes)
     */
    public Scene getTiledLayout() {
        // specify how controls (e.g. the button) will be laid out on the stage
        TilePane root = new TilePane();

        // specify spacing etc.
        root.setVgap(4);
        root.setHgap(10);
        root.setPrefColumns(3); // how many columns would you like?

        // create all the buttons to be added to the pane
        Button btnStart = new Button("Start");
        Button btnRewind = new Button("Rewind");
        Button btnPause = new Button("Pause");
        Button btnPlay = new Button("Play");
        Button btnFastForward = new Button("Fast Forward");
        Button btnEnd = new Button("End");
        Button btnStop = new Button("Stop");

        // specify that button's maximum width as very large
        btnStart.setMaxWidth(Double.MAX_VALUE);
        btnRewind.setMaxWidth(Double.MAX_VALUE);
        btnPause.setMaxWidth(Double.MAX_VALUE);
        btnPlay.setMaxWidth(Double.MAX_VALUE);
        btnFastForward.setMaxWidth(Double.MAX_VALUE);
        btnEnd.setMaxWidth(Double.MAX_VALUE);
        btnStop.setMaxWidth(Double.MAX_VALUE);

        // alternate way to add all children in a single instruction
        root.getChildren().addAll(
                btnStart,
                btnRewind,
                btnPause,
                btnPlay,
                btnFastForward,
                btnEnd,
                btnStop
        );

        return new Scene(root);
    }

    /**
     * Lay out buttons along one side of pane
     */
    public Scene getAnchorLayout() {
        // specify how controls (e.g. the button) will be laid out on the stage
        AnchorPane root = new AnchorPane();

        // container to hold buttons
        VBox vbox = new VBox();
        vbox.setFillWidth(true);
        vbox.setSpacing(10);

        // create all the buttons to be added to the pane
        Button btnStart = new Button("Start");
        Button btnRewind = new Button("Rewind");
        Button btnPause = new Button("Pause");
        Button btnPlay = new Button("Play");
        Button btnFastForward = new Button("Fast Forward");

        // specify that button's maximum width as very large
        btnStart.setMaxWidth(Double.MAX_VALUE);
        btnRewind.setMaxWidth(Double.MAX_VALUE);
        btnPause.setMaxWidth(Double.MAX_VALUE);
        btnPlay.setMaxWidth(Double.MAX_VALUE);
        btnFastForward.setMaxWidth(Double.MAX_VALUE);

        // specify that button's maximum height as very large
        btnStart.setMaxHeight(Double.MAX_VALUE);
        btnRewind.setMaxHeight(Double.MAX_VALUE);
        btnPause.setMaxHeight(Double.MAX_VALUE);
        btnPlay.setMaxHeight(Double.MAX_VALUE);
        btnFastForward.setMaxHeight(Double.MAX_VALUE);

        vbox.getChildren().addAll(btnStart, btnRewind, btnPause, btnPlay, btnFastForward);

        // add the buttons to the pane
        root.getChildren().addAll(vbox);
        //root.setBottomAnchor(vbox, 10.0);
        //root.setTopAnchor(vbox, 20.0);
        root.setRightAnchor(vbox, 10.0);

        return new Scene(root);
    }

    /**
     * Manually lay out buttons
     */
    public Scene getPaneLayout() {
        // specify how controls (e.g. the button) will be laid out on the stage
        Pane root = new Pane();

        // create all the buttons to be added to the pane
        Button btnStart = new Button("Start");
        Button btnRewind = new Button("Rewind");

        // add all children
        root.getChildren().addAll(btnStart, btnRewind);

        // specify settings
        btnStart.setLayoutX(10);
        btnStart.setLayoutY(20);
        btnStart.setPrefWidth(70);

        btnRewind.setLayoutX(70);
        btnRewind.setLayoutY(50);
        btnRewind.setPrefSize(100, 100);

        return new Scene(root);
    }

    @Override
    public void start(Stage primaryStage) {
        // called when the JavaFX application is to be set up

        // obtain the main Stage on which this application is running
        // set the title bar to "Example01"
        primaryStage.setTitle("Example02");

        // specify to the main stage that the current scene
        //primaryStage.setScene(getHorizontalLayout());
        primaryStage.setScene(getVerticalLayout());
        //primaryStage.setScene(getFlowLayout());
        //primaryStage.setScene(getStackedLayout());
        //primaryStage.setScene(getBorderLayout());
        //primaryStage.setScene(getGridLayout());
        //primaryStage.setScene(getTiledLayout());
        //primaryStage.setScene(getAnchorLayout());
        //primaryStage.setScene(getPaneLayout());

        // now then, FINALLY display the GUI
        primaryStage.show();
    }
}