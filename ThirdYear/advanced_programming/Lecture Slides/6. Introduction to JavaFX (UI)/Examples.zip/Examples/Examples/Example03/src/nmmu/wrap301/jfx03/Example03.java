package nmmu.wrap301.jfx03;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * A very basic JavaFX application in which the GUI is created manually. The
 * {@link javafx.application.Application Application} class that is extended
 * is started running by the launch method. This then calls the start method
 * which sets up the GUI.
 */
public class Example03 extends Application {
    // entry point into the application - same as always
    public static void main(String[] args) {
        // called only once. Starts a JavaFX GUI application running.
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        // called when the JavaFX application is to be set up

        // obtain the main Stage on which this application is running
        // set the title bar to "Example03"
        primaryStage.setTitle("Example03");

        // create controls for UI
        Label lbl = new Label("Name");
        TextField txtName = new TextField();
        Button btnOK = new Button("OK");

        // attach event handler to button which triggers when button clicked
        btnOK.setOnAction(event -> System.out.println("Hello " + txtName.getText()));

        // attach event handler to text field which triggers when enter is pressed
        txtName.setOnAction(event -> System.out.println("Greetings " + txtName.getText()));

        // specify how controls will be laid out on the stage
        HBox root = new HBox();
        root.setSpacing(10);
        root.getChildren().addAll(lbl, txtName, btnOK);

        // specify to the main stage that the current stage to be displayed in
        // it are described by the root stack pane, which must be of a specific
        // size (300 x 250 pixels).
        primaryStage.setScene(new Scene(root));

        // now then, FINALLY display the GUI
        primaryStage.show();
    }
}