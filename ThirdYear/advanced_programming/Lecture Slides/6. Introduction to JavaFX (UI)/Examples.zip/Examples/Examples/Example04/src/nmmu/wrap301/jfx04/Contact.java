package nmmu.wrap301.jfx04;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Contact {
    public String name;
    public String contactNumber;

    @Override
    public String toString() {
        return String.format("(%s, %s)", name, contactNumber);
    }

    public Contact(String name, String contactNumber) {
        this.name = name;
        this.contactNumber = contactNumber;
    }
}
