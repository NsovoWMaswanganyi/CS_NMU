package nmmu.wrap301.jfx04;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

public class Example04 extends Application {
    // List of contacts to navigate.
    public List<Contact> contacts;

    public int currentIndex;

    // region Cached references to controls used a lot
    public TextField txtName;
    public TextField txtNumber;
    public Label lblInfo;
    public Button btnPrev;
    public Button btnNext;
    // endregion

    public static void main(String[] args) {
        launch(args);
    }

    public void initialiseContacts() {
        contacts = new ArrayList<>();
        currentIndex = -1;

        // If want to start with some initial data uncomment this.
        // This would be the place to load data from a file or database.
        /*
        contacts.add(new Contact("Billy Bob", "081-556-1234"));
        contacts.add(new Contact("Jane Doe", "082-689-2546"));
        contacts.add(new Contact("John Doe", "084-253-1254"));
        currentIndex = 0;
        */
    }

    public void displayCurrentContact() {
        // Is it an invalid index? If so, don't allow navigation and clear the position label.
        if((contacts.size() == 0) || (currentIndex < 0) || (currentIndex >= contacts.size())) {
            txtName.setDisable(true);
            txtNumber.setDisable(true);
            btnPrev.setDisable(true);
            btnNext.setDisable(true);
            lblInfo.setText("Empty");
            return;
        };

        // Copy information to UI.
        Contact contact = contacts.get(currentIndex);
        txtName.setText(contact.name);
        txtNumber.setText(contact.contactNumber);
        lblInfo.setText(String.format("%d of %d", currentIndex+1, contacts.size()));

        // Enable text fields.
        txtName.setDisable(false);
        txtNumber.setDisable(false);

        // Disable buttons if at ends of list.
        btnPrev.setDisable(currentIndex <= 0);
        btnNext.setDisable(currentIndex >= (contacts.size() - 1));
    }

    protected Scene createScene() {
        // region Create UI
        // container for controls
        VBox root = new VBox();
        root.setSpacing(10);
        root.setPadding(new Insets(10, 10, 10, 10));

        // create controls to display contact's name
        Label lblName = new Label("Name");
        txtName = new TextField(); // NOTE: cached reference, not local.
        txtName.setId("name"); // id to look up control later

        // create controls to display contact's number
        Label lblNumber = new Label("Contact Number");
        txtNumber = new TextField();  // NOTE: cached reference, not local.
        txtNumber.setId("number"); // id to look up control later

        // info label to display current position
        lblInfo = new Label("X of Y");  // NOTE: cached reference, not local.
        lblInfo.setId("info");

        // previous button
        btnPrev = new Button("<"); // NOTE: cached reference, not local.
        btnPrev.setId("prev");

        // new button
        Button btnNew = new Button("+");
        btnNew.setId("new");

        // next button
        btnNext = new Button(">"); // NOTE: cached reference, not local.
        btnNext.setId("next");

        HBox buttons = new HBox();
        buttons.getChildren().addAll(btnPrev, btnNew, btnNext);
        buttons.setSpacing(5);
        buttons.setFillHeight(true);

        root.getChildren().addAll(
                lblName, txtName,
                lblNumber, txtNumber,
                lblInfo,
                buttons
        );
        // endregion

        // region Attach event handlers
        btnPrev.setOnAction(event -> {
            if(currentIndex == 0) return;
            currentIndex--;
            displayCurrentContact();
        });

        btnNext.setOnAction(event -> {
            if(currentIndex >= (contacts.size() - 1)) return;
            currentIndex++;
            displayCurrentContact();
        });

        btnNew.setOnAction(event -> {
            Contact contact = new Contact("?", "?");
            contacts.add(contact);
            currentIndex = contacts.size() - 1;
            displayCurrentContact();
        });

        txtName.setOnKeyPressed(event -> {
            if(event.getCode() == KeyCode.ENTER) {
                // user pressed enter, so set string value
                Contact contact = contacts.get(currentIndex);
                contact.name = txtName.getText();
                displayCurrentContact();
            };
        });
        txtName.focusedProperty().addListener((observable, oldValue, newValue) -> {
            // did the textfield lose focus, i.e. was some other control selected?
            if(!newValue) {
                // lost focus, so attempt to set value
                Contact contact = contacts.get(currentIndex);
                contact.name = txtName.getText();
                displayCurrentContact();
            }
        });

        txtNumber.setOnKeyPressed(event -> {
            if(event.getCode() == KeyCode.ENTER) {
                // user pressed enter, so set string value
                Contact contact = contacts.get(currentIndex);
                contact.contactNumber = txtNumber.getText();
                displayCurrentContact();
            };
        });
        txtNumber.focusedProperty().addListener((observable, oldValue, newValue) -> {
            // did the textfield lose focus, i.e. was some other control selected?
            if(!newValue) {
                // lost focus, so attempt to set value
                Contact contact = contacts.get(currentIndex);
                contact.contactNumber = txtNumber.getText();
                displayCurrentContact();
            }
        });

        // endregion

        return new Scene(root);
    }

    public void initialiseUI() {
        displayCurrentContact();
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Initialise data.
        initialiseContacts();

        // Create scene.
        Scene scene = createScene();

        // Copy initial data into the UI.
        initialiseUI();

        // Set stage details.
        primaryStage.setTitle("Example 4");
        primaryStage.setWidth(250);
        primaryStage.setScene(scene);

        // Show stage.
        primaryStage.show();
    }
}
