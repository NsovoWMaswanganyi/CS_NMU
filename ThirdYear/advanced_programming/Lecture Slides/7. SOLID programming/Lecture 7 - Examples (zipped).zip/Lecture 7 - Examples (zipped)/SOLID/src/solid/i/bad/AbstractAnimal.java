package solid.i.bad;

public abstract class AbstractAnimal {
    public abstract void swim();
    public abstract void fly();
    public abstract void walk();
}
