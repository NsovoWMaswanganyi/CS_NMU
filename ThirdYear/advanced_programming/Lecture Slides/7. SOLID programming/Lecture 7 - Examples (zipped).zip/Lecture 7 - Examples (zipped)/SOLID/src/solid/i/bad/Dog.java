package solid.i.bad;

public class Dog extends AbstractAnimal {
    @Override
    public void swim() {
        System.out.println("I can swim.");
    }

    @Override
    public void fly() {
        System.out.println("Pfft.");
    }

    @Override
    public void walk() {
        System.out.println("I can walk.");
    }
}
