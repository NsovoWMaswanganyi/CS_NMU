package solid.i.bad;

public class Duck extends AbstractAnimal {
    @Override
    public void swim() {
        System.out.println("I can swim.");
    }

    @Override
    public void fly() {
        System.out.println("I can fly.");
    }

    @Override
    public void walk() {
        System.out.println("I can walk.");
    }
}
