package solid.i.bad;

public class Fish extends AbstractAnimal {
    @Override
    public void swim() {
        System.out.println("I can swim.");
    }

    @Override
    public void fly() {
        System.out.println("Yeah right.");
    }

    @Override
    public void walk() {
        System.out.println("Got no feet.");
    }
}
