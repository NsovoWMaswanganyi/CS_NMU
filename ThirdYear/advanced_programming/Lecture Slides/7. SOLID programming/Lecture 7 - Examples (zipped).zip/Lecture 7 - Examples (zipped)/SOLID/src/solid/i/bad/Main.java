package solid.i.bad;

public class Main {
    public static void main(String[] args) {
        Dog dog = new Dog();
        Fish fish = new Fish();
        Duck duck = new Duck();

        // Because of abstraction, can assign many (incompatible? illogical?)
        // objects to another because of inheritence.
        // High coupling between AbstractAnimal class and animals.
        AbstractAnimal flyer = dog;
        dog.fly();
    }
}
