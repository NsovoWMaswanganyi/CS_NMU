package solid.i.good;

public class Dog implements Walker, Swimmer {
    @Override
    public void swim() {
        System.out.println("I can swim.");
    }

    @Override
    public void walk() {
        System.out.println("I can walker.");
    }
}
