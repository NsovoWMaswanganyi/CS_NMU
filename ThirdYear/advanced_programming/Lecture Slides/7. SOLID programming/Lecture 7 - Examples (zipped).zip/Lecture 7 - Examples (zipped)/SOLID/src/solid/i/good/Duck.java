package solid.i.good;

public class Duck implements Flyer, Swimmer, Walker {
    @Override
    public void fly() {
        System.out.println("I can fly.");
    }

    @Override
    public void swim() {
        System.out.println("I can swim.");
    }

    @Override
    public void walk() {
        System.out.println("I can walk.");
    }
}
