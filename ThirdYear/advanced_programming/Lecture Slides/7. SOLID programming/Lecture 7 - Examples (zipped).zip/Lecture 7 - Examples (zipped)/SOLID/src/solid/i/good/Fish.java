package solid.i.good;

public class Fish implements Swimmer {
    @Override
    public void swim() {
        System.out.println("I can swim.");
    }
}
