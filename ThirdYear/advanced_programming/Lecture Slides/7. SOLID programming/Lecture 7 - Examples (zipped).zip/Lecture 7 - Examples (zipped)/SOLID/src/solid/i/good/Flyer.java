package solid.i.good;

public interface Flyer {
    public void fly();
}
