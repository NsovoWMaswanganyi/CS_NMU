package solid.i.good;

public class Main {
    public static void main(String[] args) {
        Dog dog = new Dog();
        Fish fish = new Fish();
        Duck duck = new Duck();

        // Not possible to assign dog or fish to flyer.
        Flyer flyer = duck;
        flyer.fly();
    }
}
