package solid.i.good;

public interface Swimmer {
    public void swim();
}
