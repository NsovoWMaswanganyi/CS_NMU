package solid.i.good;

public interface Walker {
    public void walk();
}
