package solid.l;

public interface Duck {
    // SWIM Daffy! SWIM!!
    public void swim();
}
