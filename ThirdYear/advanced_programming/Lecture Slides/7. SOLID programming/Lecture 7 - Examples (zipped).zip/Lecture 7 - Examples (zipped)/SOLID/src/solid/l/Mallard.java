package solid.l;

public class Mallard implements Duck {
    @Override
    public void swim() {
        // Paddle legs. But WILL swim!
    }
}
