package solid.l.bad;

import solid.l.Duck;

public class ToyDuck implements Duck {
    private boolean turnedOn = false;

    public void turnOn() {
        turnedOn = true;
    }

    public void turnOff() {
        turnedOn = false;
    }

    public boolean isTurnedOn() {
        return turnedOn;
    }

    @Override
    public void swim() {
        // If not turn on, don't do anything...
        if(!isTurnedOn())
            return;

        // i.e. SOMETIMES swim, SOMETIMES don't
        // i.e. does not always adhere to the interface's/parent's
        // contract regarding swimming

        // Swimming logic... turn propella, quack, move legs, etc.
    }
}
