package solid.l.good;

import solid.l.Duck;

public class ToyDuck implements Duck {
    private boolean turnedOn = false;

    public void turnOn() {
        turnedOn = true;
    }

    public void turnOff() {
        turnedOn = false;
    }

    public boolean isTurnedOn() {
        return turnedOn;
    }

    @Override
    public void swim() {
        // If not turn on, then turn on...
        if(!isTurnedOn())
            turnOn();

        // Swimming logic... turn propella, quack, move legs, etc.

        // Adheres to parent's contract that duck will swim when the
        // swim method is called.
    }
}
