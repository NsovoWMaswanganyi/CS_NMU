package solid.o.bad;

import java.util.ArrayList;

public class AreaCalculator {
    // THIS method is the OCP problem. A MODIFICATION of this method
    // would be required if new functionality, e.g. a triangle class,
    // was added.
    public double area(Shape... shapes) {
        double area = 0;

        for(Shape shape : shapes) {
            if(shape instanceof Rectangle) {
                Rectangle rectangle = (Rectangle) shape;
                area += rectangle.getWidth() * rectangle.getHeight();

            } else if(shape instanceof Circle) {
                Circle circle = (Circle) shape;
                area += 2 * Math.PI * circle.getRadius() * circle.getRadius();
            }
        }

        return area;
    }
}
