package solid.o.bad;

public class Main {
    public static void main(String[] args) {
        AreaCalculator ac = new AreaCalculator();

        System.out.println(ac.area(
                new Rectangle(1,2),
                new Circle(3.5)));
    }
}
