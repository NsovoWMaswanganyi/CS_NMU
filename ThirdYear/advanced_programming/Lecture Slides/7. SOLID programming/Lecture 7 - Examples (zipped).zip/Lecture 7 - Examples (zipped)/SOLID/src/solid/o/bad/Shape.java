package solid.o.bad;

public abstract class Shape {
}
