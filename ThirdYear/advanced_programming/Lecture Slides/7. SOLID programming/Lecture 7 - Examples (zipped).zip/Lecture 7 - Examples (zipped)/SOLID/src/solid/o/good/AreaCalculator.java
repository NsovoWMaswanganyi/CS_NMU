package solid.o.good;

public class AreaCalculator {
    // Regardless of how many new shapes there are, this
    // method will not need to be modified - EVER!
    public double area(Shape... shapes) {
        double area = 0;

        for(Shape shape : shapes) {
            area += shape.area();
        }

        return area;
    }
}
