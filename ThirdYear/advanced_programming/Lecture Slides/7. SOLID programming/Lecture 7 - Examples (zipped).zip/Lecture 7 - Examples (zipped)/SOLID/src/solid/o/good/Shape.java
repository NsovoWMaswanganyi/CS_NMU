package solid.o.good;

// From Interface Segregation Principle, better to program
// to an interface (more reusable)
public interface Shape {
    public double area();
}
