package solid.s.bad;

/**
 * Example of why not using the Open/Close principle can lead to
 * bad things.
 */
public class GameScore {
    // Private field is good.
    private int score = 0;

    // Getting the score is good.
    public int getScore() {
        return score;
    }

    // Setting the score can lead to game score related logic
    // being OUTSIDE the class. See main method, i.e. Single
    // Responsibility Principle.
    public void setScore(int score) {
        this.score = score;
    }

    public void display() {
        System.out.println("Score = " + score);
    }
}
