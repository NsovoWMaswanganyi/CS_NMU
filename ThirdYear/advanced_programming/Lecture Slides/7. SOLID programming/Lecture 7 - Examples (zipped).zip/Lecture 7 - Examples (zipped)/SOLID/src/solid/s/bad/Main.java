package solid.s.bad;

public class Main {
    public static final int ENEMY_BOSS_POINTS = 100;
    public static final int ENEMY_GRUNT_POINTS = 5;
    public static final int LEVEL_COMPLETED_POINTS = 10;

    public static void main(String[] args) {
        double scoreBoost = 1;
        GameScore gameScore = new GameScore();

        // Stuff happens, then killed a boss enemy.
        gameScore.setScore((int) (gameScore.getScore() + ENEMY_BOSS_POINTS * scoreBoost));

        // More stuff happens, and got a score boost
        scoreBoost = 1.5;

        // Yet more stuff happens and killed a grunt
        gameScore.setScore((int) (gameScore.getScore() + ENEMY_GRUNT_POINTS * scoreBoost));

        // The problem with the above code is that the LOGIC of
        // dealing with the gameScore score happens OUTSIDE the object
        // that is supported to be dealing with it.

        // The problem with this is that gameScore is supposed to manage
        // the game scoring, BUT is also displaying the data. What if wanted
        // to have the score displayed differently?
        gameScore.display();
    }
}
