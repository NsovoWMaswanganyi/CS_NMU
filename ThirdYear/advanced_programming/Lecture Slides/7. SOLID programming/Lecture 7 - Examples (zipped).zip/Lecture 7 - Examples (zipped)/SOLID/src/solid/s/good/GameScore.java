package solid.s.good;

public class GameScore {
    // Maximum boost allowed
    private static final double MAX_BOOST = 2;

    // Good - should be private
    private int score = 0;
    private double scoreBoost = 1;

    // Get the score
    public int getScore() {
        return score;
    }

    public double getScoreBoost() {
        return scoreBoost;
    }

    /**
     * Sets the score boost being used. Allowed values are between
     * 0 (can't increase score) to MAX_BOOST (maximum double points).
     * @param scoreBoost
     */
    public void setScoreBoost(double scoreBoost) {
        this.scoreBoost = Math.min(Math.max(0, scoreBoost), MAX_BOOST);
    }

    // TELL the object what to do, i.e. update the score

    /**
     * Updates the score, applying a boost (or penalty) to the points
     * @param points
     */
    public void updateScore(int points) {
        score += points * scoreBoost;
    }

    // NO display methods anymore as violates SRP.
}
