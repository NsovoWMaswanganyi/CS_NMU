package solid.s.good;

public class Main {
        public static final int ENEMY_BOSS_POINTS = 100;
        public static final int ENEMY_GRUNT_POINTS = 5;
        public static final int LEVEL_COMPLETED_POINTS = 10;

        public static void main(String[] args) {
            GameScore gameScore = new GameScore();
            ScoreRenderer scoreRenderer = new ScoreRenderer(gameScore);

            // Stuff happens, then killed a boss enemy.
            gameScore.updateScore(ENEMY_BOSS_POINTS);

            // More stuff happens, pick up score booster (150%)
            gameScore.setScoreBoost(1.5);

            // Yet more stuff happens, then killed a grunt, now at 150% boosted
            // value, i.e. grunt now worth 7.5 instead of 5.
            gameScore.updateScore(ENEMY_GRUNT_POINTS);

            // Better, because the logic of updating score dealt with
            // by GameScore object, not THIS object.

            // Render score, done by object responsible for this.
            scoreRenderer.render();
        }
}
