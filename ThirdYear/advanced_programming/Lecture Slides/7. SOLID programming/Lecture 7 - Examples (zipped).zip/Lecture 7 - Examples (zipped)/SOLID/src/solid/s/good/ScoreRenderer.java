package solid.s.good;

/**
 * The responsibility of this class is to render the score so that
 * the user can see it visually.
 */
public class ScoreRenderer {
    // Good - private data.
    private GameScore score;

    // Good - passing in score object instance when needed, i.e.
    // can pass in subclasses of GameScore if wanted too. Not
    // bound as would be if private GameScore score = new GameScore();
    // would have done.
    public ScoreRenderer(GameScore score) {
        this.score = score;
    }

    // Render the score
    public void render() {
        String s = "Score: " + score.getScore();
        if(score.getScoreBoost() < 1)
            s = s + "--";
        if(score.getScoreBoost() > 1)
            s = s + "++";

        System.out.println(s);
    }
}
