package nmmu.wrap301.jfx01;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * Example showing how the data entered and UI need to be synched if doing
 * it <b>manually</b>. A <i>lot</i> of work!!
 */
public class Example01 extends Application {
    // Model to be used by the UI
    private StudentModel student = new StudentModel("12345", "Billy Bob", 17, false);

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        //region Create UI Controls
        VBox vb = new VBox();
        vb.setSpacing(10);
        vb.setPadding(new Insets(10));

        Label lblStudentNo = new Label("Student Number:");
        TextField txtStudentNo = new TextField();

        Label lblName = new Label("Name:");
        TextField txtName = new TextField();

        Label lblAge = new Label("Age:");
        TextField txtAge = new TextField();

        Slider sldAge = new Slider();
        sldAge.setMax(100);
        sldAge.setMin(1);

        Label lblPassed = new Label("Passed:");
        TextField txtPassed = new TextField();
        CheckBox cbxPassed = new CheckBox("Passed");

        Button btnOK = new Button("Display & Clear");
        btnOK.setMaxWidth(Double.MAX_VALUE);
        //endregion

        //region Set initial values of UI to match student data
        txtStudentNo.setText(student.studentNumber);
        txtName.setText(student.name);
        txtAge.setText(student.age.toString());
        sldAge.valueProperty().setValue(student.age);
        txtPassed.setText(student.passed.toString());
        cbxPassed.setSelected(student.passed);
        //endregion

        //region Attach event handlers to controls.
        btnOK.setOnAction(event -> {
            // display student info
            System.out.printf("Student = %s\n", student);

            // modify student data model
            student.studentNumber = "0";
            student.name = "?";
            student.age = 0;
            student.passed = false;

            // update UI to reflect this
            txtStudentNo.setText(student.studentNumber);
            txtName.setText(student.name);
            txtAge.setText(student.age.toString());
            sldAge.valueProperty().setValue(student.age);
            txtPassed.setText(student.passed.toString());
            cbxPassed.setSelected(student.passed);
        });

        // linking student number to text field
        // link text editing to student model and other UI controls
        txtStudentNo.setOnKeyPressed(event -> {
            if(event.getCode() == KeyCode.ENTER) {
                // user pressed enter, so set string value
                student.studentNumber = txtStudentNo.getText();
                System.out.println("Set student number to " + student.studentNumber);
            };
        });
        txtStudentNo.focusedProperty().addListener((observable, oldValue, newValue) -> {
            // did the textfield lose focus, i.e. was some other control selected?
            if(!newValue) {
                // lost focus, so attempt to set value
                student.studentNumber = txtStudentNo.getText();
                System.out.println("Set student number to " + student.studentNumber);
            }
        });

        // linking student name to text field
        // link text editing to student model and other UI controls
        txtName.setOnKeyPressed(event -> {
            if(event.getCode() == KeyCode.ENTER) {
                // user pressed enter, so set string value
                student.name = txtName.getText();
                System.out.println("Set student name to " + student.name);
            };
        });
        txtName.focusedProperty().addListener((observable, oldValue, newValue) -> {
            // did the textfield lose focus, i.e. was some other control selected?
            if(!newValue) {
                // lost focus, so attempt to set value
                student.name = txtName.getText();
                System.out.println("Set student name to " + student.name);
            }
        });

        // linking student age to text field - can ONLY be a value integer
        // link text editing to student model and other UI controls
        txtAge.setOnKeyPressed(event -> {
            if(event.getCode() == KeyCode.ENTER) {
                // user pressed enter, so set string value -  attempt to convert to an integer
                try {
                    student.age = Integer.parseInt(txtAge.getText());
                    System.out.println("Set student age to " + student.age);
                    // age linked to sliding bar, so adjust it
                    sldAge.valueProperty().setValue(student.age);
                } catch(Exception e) {
                    System.out.println("Error, could not convert " + txtAge.getText() + " to an integer.");
                }
            };
        });
        txtAge.focusedProperty().addListener((observable, oldValue, newValue) -> {
            // did the textfield lose focus, i.e. was some other control selected?
            if(!newValue) {
                // lost focus, so attempt to set value
                try {
                    student.age = Integer.parseInt(txtAge.getText());
                    System.out.println("Set student age to " + student.age);
                    // age linked to sliding bar, so adjust it
                    sldAge.valueProperty().setValue(student.age);
                } catch(Exception e) {
                    System.out.println("Error, could not convert " + txtAge.getText() + " to an integer.");
                }
            }
        });
        sldAge.valueProperty().addListener((observable, oldValue, newValue) -> {
            // update student data
            student.age = (int) sldAge.valueProperty().get();
            // update text field
            txtAge.setText(student.age.toString());
            System.out.println("Set student age to " + student.age);
        });

        // linking student passed to text field and check box
        // link text editing to student model and other UI controls
        txtPassed.setOnKeyPressed(event -> {
            if(event.getCode() == KeyCode.ENTER) {
                // user pressed enter, so set string value - if valid
                if(txtPassed.getText().equalsIgnoreCase("true")) {
                    student.passed = true;
                    System.out.println("Set student passed to true.");
                    cbxPassed.setSelected(true);
                } else                 if(txtPassed.getText().equalsIgnoreCase("false")) {
                    student.passed = false;
                    System.out.println("Set student passed to false.");
                    cbxPassed.setSelected(false);
                } else {
                    // invalid word, so reset
                    txtPassed.setText(student.passed.toString());
                    System.out.println("Invalid word, only 'true' or 'false' allowed.");
                }
            };
        });
        txtPassed.focusedProperty().addListener((observable, oldValue, newValue) -> {
            // did the textfield lose focus, i.e. was some other control selected?
            // user pressed enter, so set string value - if valid
            if(!newValue) {
                if (txtPassed.getText().equalsIgnoreCase("true")) {
                    student.passed = true;
                    System.out.println("Set student passed to true.");
                    cbxPassed.setSelected(true);
                } else if (txtPassed.getText().equalsIgnoreCase("false")) {
                    student.passed = false;
                    System.out.println("Set student passed to false.");
                    cbxPassed.setSelected(false);
                } else {
                    // invalid word, so reset
                    txtPassed.setText(student.passed.toString());
                    System.out.println("Invalid word, only 'true' or 'false' allowed.");
                }
            }
        });
        cbxPassed.selectedProperty().addListener((observable, oldValue, newValue) -> {
            // update student model and text
            student.passed = newValue;
            txtPassed.setText(student.passed.toString());
            System.out.println("Set student passed to " + student.passed);
        });
        //endregion

        //region Add controls to container
        vb.getChildren().addAll(
                lblStudentNo, txtStudentNo,
                lblName, txtName,
                lblAge, txtAge, sldAge,
                lblPassed, txtPassed, cbxPassed,
                btnOK
        );
        //endregion

        //region Setup and start scene
        primaryStage.setTitle("Example 1");
        primaryStage.setScene(new Scene(vb));
        primaryStage.setMinWidth(300);
        primaryStage.show();
        //endregion
    }
}
