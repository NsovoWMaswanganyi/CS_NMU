package nmmu.wrap301.jfx01;

/**
 * Data related to a student. <b>Nothing</b> of the UI should be mentioned
 * or used here.
 */
public class StudentModel {
    public String studentNumber = "0";
    public String name = "?";
    public Integer age = 1;
    public Boolean passed = false;

    @Override
    public String toString() {
        return String.format("(%s) %s, age = %d, passed = %s\n", studentNumber, name, age, passed);
    }

    public StudentModel(String studentNumber, String name, Integer age, Boolean passed) {
        this.studentNumber = studentNumber;
        this.name = name;
        this.age = age;
        this.passed = passed;
    }
}
