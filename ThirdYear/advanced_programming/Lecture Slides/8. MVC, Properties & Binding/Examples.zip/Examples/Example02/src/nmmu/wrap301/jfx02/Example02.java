package nmmu.wrap301.jfx02;

import javafx.beans.InvalidationListener;
import javafx.beans.binding.*;
import javafx.beans.property.FloatProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleFloatProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ChangeListener;

/**
 */
public class Example02 {
    /**
     * <p>
     *     A property that can be changed and will notify anyone listening to it of the change.
     *     IntegerProperty is an <b>abstract</b> class, so a non-abstract (concrete) implementation
     *     is required, of which there are a couple to choose from.
     * </p>
     */
    private static IntegerProperty ip = new SimpleIntegerProperty(-100);

    public static void main(String[] args) {
        createProperty();
        testChangeListeners();
        testBinding();
        testBiDirectionalBinding();
        testCalculatedValueBinding();
    }

    /**
     * Create a new integer property and set an initial value.
     */
    private static void createProperty() {
        System.out.println("Create Property...");

        // create a concrete IntegerProperty using the SimpleIntegerProperty class
        ip = new SimpleIntegerProperty(301);

        // display some info about the property
        System.out.printf("ip = %s\n", ip);
        System.out.printf("ip.get() = %s (type = int)\n", ip.get());
        System.out.printf("ip.getValue() = %s (type = Integer)\n", ip.getValue());
    }


    public static void testChangeListeners() {
        System.out.println();
        System.out.println("Change Listeners...");

        // the code that will be called if the property changes its value
        ChangeListener listener = (observable, oldValue, newValue) ->
                System.out.printf("Value changed, old_value = %s, new_value = %s\n", oldValue, newValue);

        // attach the event handler to the property
        ip.addListener(listener);
        System.out.println("Attached change listener...");

        // change value of property
        ip.set(100);                    // int version - triggers change
        ip.setValue(new Integer(200));  // Integer version - triggers change

        // display ip value. The act of asking for the value makes it valid again.
        System.out.printf("ip.get() = %s\n", ip.get());

        // changing value will trigger change again
        ip.set(250);

        // remove event handler
        ip.removeListener(listener);
        System.out.println("Removed change listener...");

        // change values again - does not trigger change event
        ip.set(300); // int version
    }

    /**
     * Creating a one-directional binding from one property to another.
     */
    public static void testBinding() {
        System.out.println();
        System.out.println("1-way Bindings...");

        // display current value of ip
        System.out.printf("ip.get() = %s\n", ip.get());

        // create another property
        IntegerProperty anotherIp = new SimpleIntegerProperty(0);
        System.out.printf("anotherIp.get() = %s\n", anotherIp.get());

        // one directional binding of anotherIp to ip (anotherIp's value = ip's value)
        anotherIp.bind(ip);
        System.out.println("1-Directional bind anotherIp to ip...");
        System.out.printf("anotherIp.get() = %s\n", anotherIp.get());

        // change ip's value
        ip.set(500);
        System.out.println("Changed ip's value...");
        System.out.printf("ip.get() = %s\n", ip.get());
        System.out.printf("anotherIp.get() = %s\n", anotherIp.get());

        // a bound property cannot be changed, i.e. the following will not work
        // anotherIp.set(999);

        // unbind
        anotherIp.unbind();
        System.out.println("Unbinding anotherIp...");
        ip.set(700);
        System.out.println("Changed ip's value...");
        System.out.printf("ip.get() = %s\n", ip.get());
        System.out.printf("anotherIp.get() = %s\n", anotherIp.get());
    }

    /**
     * Creating bi-directional bindings
     */
    private static void testBiDirectionalBinding() {
        System.out.println();
        System.out.println("2-way Bindings...");

        // create another property
        IntegerProperty anotherIp = new SimpleIntegerProperty(0);

        // create the binding
        System.out.println("Creating a bi-directional binding between anotherIp and ip...");
        anotherIp.bindBidirectional(ip);

        // change values
        ip.setValue(100);
        System.out.println("Changed ip's value...");
        System.out.printf("ip.get() = %s\n", ip.get());
        System.out.printf("anotherIp.get() = %s\n", anotherIp.get());

        anotherIp.setValue(200);
        System.out.println("Changed anotherIp's value...");
        System.out.printf("ip.get() = %s\n", ip.get());
        System.out.printf("anotherIp.get() = %s\n", anotherIp.get());

        // unbind
        ip.unbindBidirectional(anotherIp);
        System.out.println("Unbinding ip from anotherIp...");
    }

    /**
     * Creating bindings from one property onto more than one other property.
     * where the value of the bound property is a calculation based on the
     * other properties.
     */
    public static void testCalculatedValueBinding() {
        System.out.println();
        System.out.println("Calculated Bindings...");

        // properties that will be depended on
        FloatProperty width = new SimpleFloatProperty(5.0f);
        FloatProperty height = new SimpleFloatProperty(10.0f);
        FloatProperty radius = new SimpleFloatProperty(2.0f);

        // create a calculation that depends on two properties. manually create the calculation
        FloatBinding rectArea = new FloatBinding() {
            // unnamed constructor
            {
                // binding this binding to the width and height properties
                // i.e. if either one changes, computeValue will be called
                super.bind(width, height);
            }

            @Override
            protected float computeValue() {
                return width.get() * height.get();
            }
        };

        /*
        rectArea.addListener((observable, oldValue, newValue) -> {
            System.out.println(">> Rectangle area changed to " + newValue.intValue());
        });
         */

        // create a binding using the Fluent API, circleArea = PI * radius * radius
        NumberBinding circleArea = radius.multiply(radius).multiply(Math.PI);

        /*
        circleArea.addListener((observable, oldValue, newValue) -> {
            System.out.println(">> Circle area changed to " + newValue.intValue());
        });
         */

        // can create bindings with other types too
        StringBinding message = (StringBinding) Bindings
                .concat("Circle area = ")
                .concat(circleArea)
                .concat(", Rectangle area = ")
                .concat(rectArea);

        /*
        message.addListener((observable, oldValue, newValue) -> {
            System.out.printf(">> Message changed to '%s'\n", newValue);
        });
         */

        // can use simple logic using the Fluent API as well
        StringBinding largerMessage = (StringBinding) Bindings
                .when(width.greaterThan(height))
                .then(Bindings.concat("Width is larger = ").concat(width))
                .otherwise(Bindings.concat("Height is larger = ").concat(height));

        /*
        largerMessage.addListener((observable, oldValue, newValue) -> {
            System.out.printf(">> Larger message changed to '%s'\n", newValue);
        });
         */

        // display the area
        System.out.println("Displaying values...");
        System.out.printf("width.get() = %s\n", width.get());
        System.out.printf("height.get() = %s\n", height.get());
        System.out.printf("radius.get() = %s\n", radius.get());
        System.out.printf("rectArea.get() = %s\n", rectArea.get());
        System.out.printf("circleArea.getValue() = %s\n", circleArea.getValue());
        System.out.printf("message.getValue() = '%s'\n", message.getValue());
        System.out.printf("largerMessage.getValue() = '%s'\n", largerMessage.getValue());
        System.out.println();

        // change property values
        System.out.println("Changing property values...");
        width.set(15.0f);
        radius.set(15.0f);

        System.out.println();
        System.out.println("Displaying values...");
        System.out.printf("width.get() = %s\n", width.get());
        System.out.printf("height.get() = %s\n", height.get());
        System.out.printf("radius.get() = %s\n", radius.get());
        System.out.printf("rectArea.get() = %s\n", rectArea.get());
        System.out.printf("circleArea.getValue() = %s\n", circleArea.getValue());
        System.out.printf("message.getValue() = '%s'\n", message.getValue());
        System.out.printf("largerMessage.getValue() = '%s'\n", largerMessage.getValue());
    }

}
