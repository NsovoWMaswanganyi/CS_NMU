package nmmu.wrap301.jfx03;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.converter.BooleanStringConverter;
import javafx.util.converter.NumberStringConverter;

/**
 * How to link data model and UI using binding. A <i>lot</i> easier!
 */
public class Example03 extends Application {
    // model to be used by the UI
    public StudentModel student = new StudentModel("12345", "Billy Bob", 17, false);

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        //region Create UI controls
        VBox vb = new VBox();
        vb.setSpacing(5);
        vb.setPadding(new Insets(10));

        Label lblStudentNo = new Label("Student Number:");
        TextField txtStudentNo = new TextField();

        Label lblName = new Label("Name:");
        TextField txtName = new TextField();

        Label lblAge = new Label("Age:");
        TextField txtAge = new TextField();

        Slider sldAge = new Slider();
        sldAge.setMax(100);
        sldAge.setMin(1);

        Label lblPassed = new Label("Passed:");
        TextField txtPassed = new TextField();
        CheckBox cbxPassed = new CheckBox("Passed");

        Button btnOK = new Button("Display & Clear");
        btnOK.setMaxWidth(Double.MAX_VALUE);

        vb.getChildren().addAll(
                lblStudentNo, txtStudentNo,
                lblName, txtName,
                lblAge, txtAge, sldAge,
                lblPassed, txtPassed, cbxPassed,
                btnOK
        );
        //endregion

        //region Adding some controller response code
        btnOK.setOnAction(event -> {
            // display student info
            System.out.printf("Student = %s\n", student);

            // modify student
            student.studentNumber.set("0");
            student.name.setValue("?");
            student.age.set(0);
            student.passed.set(false);
        });
        //endregion

        //region Bind UI control properties to model properties

        // string <-> string binding
        txtStudentNo.textProperty().bindBidirectional(student.studentNumber);
        // string <-> string binding
        txtName.textProperty().bindBidirectional(student.name);

        // bind text field AND slider to student's age
        // string <-> integer binding, so need to know how to convert between the two
        txtAge.textProperty().bindBidirectional(student.age, new NumberStringConverter());
        sldAge.valueProperty().bindBidirectional(student.age);

        // bind text field AND check box to student's passed field
        // string <-> boolean binding, so need to know how to convert between the two
        txtPassed.textProperty().bindBidirectional(student.passed, new BooleanStringConverter());
        cbxPassed.selectedProperty().bindBidirectional(student.passed);
        //endregion

        //region Setup and start scene
        primaryStage.setTitle("Example 3");
        primaryStage.setScene(new Scene(vb));
        primaryStage.setMinWidth(300);
        primaryStage.show();
        //endregion
    }
}
