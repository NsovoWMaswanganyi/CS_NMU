package nmmu.wrap301.jfx03;

import javafx.beans.property.*;

/**
 * Data related to a student. <b>Nothing</b> of the UI should be mentioned
 * or used here.
 */
public class StudentModel {
    public StringProperty studentNumber = new SimpleStringProperty("");
    public StringProperty name = new SimpleStringProperty("");
    public IntegerProperty age = new SimpleIntegerProperty(1);
    public BooleanProperty passed = new SimpleBooleanProperty(false);

    @Override
    public String toString() {
        return String.format("(%s) %s, age = %d, passed = %s\n",
                studentNumber.get(),
                name.get(),
                age.get(),
                passed.get());
    }

    public StudentModel(String studentNumber, String name, int age, Boolean passed) {
        this.studentNumber.set(studentNumber);
        this.name.set(name);
        this.age.set(age);
        this.passed.set(passed);
    }
}
