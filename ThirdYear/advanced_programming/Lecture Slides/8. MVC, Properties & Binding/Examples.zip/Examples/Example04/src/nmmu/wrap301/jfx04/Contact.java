package nmmu.wrap301.jfx04;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Contact {
    // Made private so that other users of this class CANNOT allocate new
    // object instances - which would break everything.
    private StringProperty name = new SimpleStringProperty();
    private StringProperty contactNumber = new SimpleStringProperty();

    @Override
    public String toString() {
        return String.format("(%s, %s)", name.getValue(), contactNumber.getValue());
    }

    public StringProperty nameProperty() {
        return name;
    }

    public StringProperty contactNumberProperty() {
        return contactNumber;
    }

    public Contact(String name, String contactNumber) {
        this.name.set(name);
        this.contactNumber.set(contactNumber);
    }
}
