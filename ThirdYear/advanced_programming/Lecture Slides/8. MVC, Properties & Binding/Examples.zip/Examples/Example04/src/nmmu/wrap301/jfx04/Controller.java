package nmmu.wrap301.jfx04;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.Property;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import java.util.ArrayList;

public class Controller {
    //region Properties used to control the app.
    // List of contacts
    private ArrayList<Contact> contacts = new ArrayList<Contact>();

    // The index of the current contact
    private IntegerProperty currentIndex = new SimpleIntegerProperty(-1);

    // The number of contacts
    private IntegerProperty currentSize = new SimpleIntegerProperty(0);

    // The current contact being viewed and edited
    private Property<Contact> currentContact = new SimpleObjectProperty<Contact>();
    //endregion

    //region Cached references to scene's controls - looked up using their IDs
    private TextField txtName;
    private TextField txtContactNumber;
    private Label lblInfo;
    private Button btnPrev;
    private Button btnNew;
    private Button btnNext;
    //endregion

    public Controller(Scene scene) {
        connectToUI(scene);
        setupContacts();
        setupProperties();
        first();
    }

    /**
     * Add some dummy contacts
     */
    private void setupContacts() {
        System.out.println("Adding contacts.");

        contacts.add(new Contact("Billy Bob", "081-556-1234"));
        contacts.add(new Contact("Jane Doe", "082-689-2546"));
        contacts.add(new Contact("John Doe", "084-253-1254"));

        // Update size - which will initialise the Fluent binding.
        // The ArrayList does not have bindings, so need to update manually.
        currentSize.set(contacts.size());
    }

    //region Contact navigation methods
    public void first() {
        System.out.println("|<\tFirst.");

        if (contacts.size() > 0)
            currentIndex.set(0);
    }

    public void last() {
        System.out.println(">|\tLast.");

        if (contacts.size() > 0)
            currentIndex.set(contacts.size() - 1);
    }

    public void next() {
        System.out.println(">>\tNext.");

        if (currentIndex.get() < (contacts.size() - 1))
            currentIndex.set(currentIndex.get() + 1);
    }

    public void previous() {
        System.out.println("<<\tPrev.");

        if (currentIndex.get() > 0)
            currentIndex.set(currentIndex.get() - 1);
    }

    public void newContact() {
        System.out.println("[]\tNew.");

        // Create new contact
        Contact contact = new Contact("?", "?");

        // Add to contacts
        contacts.add(contact);

        // Update size property
        currentSize.set(contacts.size());

        // Set current to last
        last();
    }
    //endregion

    //region Setup and management of event handlers and bindings.
    /**
     * Bind the UI controls and the controller properties together.
     *
     * @param scene
     */
    public void connectToUI(Scene scene) {
        //region Obtain references to controls.
        System.out.println("Obtaining references to scene controls by id.");

        txtName = (TextField) scene.lookup("#name");
        txtContactNumber = (TextField) scene.lookup("#number");
        lblInfo = (Label) scene.lookup("#info");
        btnPrev = (Button) scene.lookup("#prev");
        btnNew = (Button) scene.lookup("#new");
        btnNext = (Button) scene.lookup("#next");
        //endregion

        //region Setup bindings that don't need to change once the app runs.
        // Set binding for label using a Fluent binding
        lblInfo.textProperty().bind(
                currentIndex.add(1).asString().concat(" of ").concat(currentSize)
        );
        //endregion

        //region Attach event handlers to buttons.
        btnPrev.setOnAction(event -> previous());
        btnNew.setOnAction(event -> newContact());
        btnNext.setOnAction(event -> next());
        //endregion
    }

    private void setupProperties() {
        System.out.println("Setting up properties.");

        // Change the current contact if the current index changes
        currentIndex.addListener((observable, oldValue, newValue) -> {
            // If new index value within the allowed range, get the contact
            if ((newValue.intValue() >= 0) && (newValue.intValue() < contacts.size())) {
                System.out.printf("Current index changed, old = %s, new = %s\n", oldValue.intValue(), newValue.intValue());
                currentContact.setValue(contacts.get(newValue.intValue()));
            }
        });

        // Update bindings to the current contact if it changed
        currentContact.addListener((observable, oldValue, newValue) -> {
            System.out.printf("Contact changed, old = %s, new = %s\n", oldValue, newValue);
            rebindFields(oldValue, newValue);
        });
    }

    /**
     * Unbinds any bindings to the text fields, then rebinds to the current
     * contact's properties. This method must only be called AFTER obtaining
     * references to the scene's controls, i.e. after connectToUI
     */
    private void rebindFields(Contact oldContact, Contact newContact) {
        // Remove old bindings to the old contact (if there was one)
        if (oldContact != null) {
            System.out.println("Removing text field bi-directional bindings from " + oldContact);
            txtName.textProperty().unbindBidirectional(oldContact.nameProperty());
            txtContactNumber.textProperty().unbindBidirectional(oldContact.contactNumberProperty());
        }

        // Add bindings to new contact
        if (newContact != null) {
            System.out.println("Adding text field bi-directional bindings to " + newContact);
            txtName.textProperty().bindBidirectional(newContact.nameProperty());
            txtContactNumber.textProperty().bindBidirectional(newContact.contactNumberProperty());
        }
    }
    //endregion
}
