package nmmu.wrap301.jfx04;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * This example demonstrates using a controller class (in which the logic of the application resides),
 * and using bindings to easily link the controller to the scene.
 */
public class Example04 extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    /**
     * Create the scene that will be used to display a single contact
     * Note that no event handlers are attached and that each control has an ID
     * that can be used to locate it later - you will see this type of functionality
     * when we get to Android as well.
     * @return
     */
    protected Scene createScene() {
        // container for controls
        VBox root = new VBox();
        root.setSpacing(10);
        root.setPadding(new Insets(10, 10, 10, 10));

        // create controls to display contact's name
        Label lblName = new Label("Name");
        TextField txtName = new TextField();
        txtName.setId("name"); // id to look up control later

        // create controls to display contact's number
        Label lblNumber = new Label("Contact Number");
        TextField txtNumber = new TextField();
        txtNumber.setId("number"); // id to look up control later

        // info label to display current position
        Label lblInfo = new Label("X of Y");
        lblInfo.setId("info");

        // previous button
        Button btnPrev = new Button("<");
        btnPrev.setId("prev");

        // new button
        Button btnNew = new Button("+");
        btnNew.setId("new");

        // next button
        Button btnNext = new Button(">");
        btnNext.setId("next");

        HBox buttons = new HBox();
        buttons.getChildren().addAll(btnPrev, btnNew, btnNext);
        buttons.setSpacing(5);
        buttons.setFillHeight(true);

        root.getChildren().addAll(
                lblName, txtName,
                lblNumber, txtNumber,
                lblInfo,
                buttons
        );

        return new Scene(root);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Create scene - NO event handlers attached.
        Scene scene = createScene();

        // Create controller and connect it to scene.
        // Event handlers will be attached by the controller.
        Controller controller = new Controller(scene);

        // Set stage details.
        primaryStage.setTitle("Example 4");
        primaryStage.setWidth(250);
        primaryStage.setScene(scene);

        // Show stage.
        primaryStage.show();

    }
}
