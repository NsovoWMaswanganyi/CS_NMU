package nmmu.wrap301.jfx01;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Contact {
    // region Properties that will be used to connect to the UI
    private StringProperty name = new SimpleStringProperty();
    private StringProperty contactNumber = new SimpleStringProperty();
    // endregion

    // The ListView uses the toString method to decide what to display in a line.
    @Override
    public String toString() {
        return String.format("(%s, %s)", name.getValue(), contactNumber.getValue());
    }

    // region Getters for the properties - to prevent other developers from accidently overwriting a property.
    public StringProperty nameProperty() {
        return name;
    }

    public StringProperty contactNumberProperty() {
        return contactNumber;
    }
    // endregion

    public Contact(String name, String contactNumber) {
        this.name.set(name);
        this.contactNumber.set(contactNumber);
    }
}
