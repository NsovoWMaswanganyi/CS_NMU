package nmmu.wrap301.jfx01;

import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.util.Callback;

import java.util.ArrayList;

public class Controller {
    // List of contacts in an UNOBSERVED list.
    private ArrayList<Contact> contacts = new ArrayList<Contact>();

    // Observable List needed by the ListView to know when to refresh itself (i.e. when adding or removing
    // items from the list being displayed).
    private ObservableList<Contact> observableContacts;

    public Controller() {
        setupContacts();
    }

    /**
     * Add some dummy contacts
     */
    private void setupContacts() {
        System.out.println("Adding contacts.");

        contacts.add(new Contact("Billy Bob", "081-556-1234"));
        contacts.add(new Contact("Jane Doe", "082-689-2546"));
        contacts.add(new Contact("Joe Soap", "084-253-1254"));
    }

    // region Cached references to scene's controls
    private TextField txtName;
    private TextField txtContactNumber;
    private Button btnNew;
    private ListView<Contact> lbxContacts;
    // endregion

    /**
     * Bind the UI controls and the controller properties together.
     * @param scene The scene being bound too.
     */
    public void connectToUI(Scene scene) {
        // region Obtain cached references to controls for easy use later.
        System.out.println("Obtaining references to scene controls by id.");

        txtName = (TextField) scene.lookup("#name");
        txtContactNumber = (TextField) scene.lookup("#number");
        btnNew = (Button) scene.lookup("#new");
        lbxContacts = (ListView) scene.lookup("#contacts");
        // endregion

        // region Set up the objects to be viewed, as well as WHEN the ListView will be refreshed.
        /*
            Create an extractor that provides the ListView with an array of properties that
            would cause the toString method to display something else, i.e. the ListView will watch
            these properties to decide when to refresh itself.

            The extractor is given an object when you ADD something to the ListView collection it is
            displaying. Given the object, the extractor simply returns an array to properties. The ListView
            will attach listeners to these properties. When the object is REMOVED from the collection,
            the ListView will stop watching the properties.
         */
        Callback<Contact, Observable[]> extractor = contact -> {
            return new Observable[] {contact.contactNumberProperty(), contact.nameProperty()};
        };

        /*
            Create a new ObservableArrayList (to the ListView is told WHEN objects are added and removed).
            An extractor is provided IF you want the ListView to refresh if the contents of the object
            are changed (i.e. a contact's name or number).
         */
        observableContacts = FXCollections.observableArrayList(extractor);

        // Add some dummy contacts. Note adding contents of an unobserved list to the observed list.
        observableContacts.addAll(contacts);

        // Tell the ListView WHAT it is to display.
        lbxContacts.setItems(observableContacts);
        // endregion

        // region When select item in ListView, bind/unbind properties of the TextFields
        lbxContacts.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            System.out.printf("old = '%s', new = '%s'\n", oldValue, newValue);

            // remove the old binding if it exists
            if (oldValue != null) {
                System.out.printf("unbinding from '%s', ", oldValue);
                txtName.textProperty().unbindBidirectional(oldValue.nameProperty());
                txtContactNumber.textProperty().unbindBidirectional(oldValue.contactNumberProperty());
            }

            // if the new value is not null
            if (newValue != null) {
                // bind to the new one
                System.out.printf("binding to '%s'\n", newValue);
                txtName.textProperty().bindBidirectional(newValue.nameProperty());
                txtContactNumber.textProperty().bindBidirectional(newValue.contactNumberProperty());
            }
        });
        // endregion

        // region Add event handler for New Button.
        btnNew.setOnAction(event -> {
            Contact contact = new Contact("?", "000-000-0000");
            lbxContacts.getItems().add(contact);
            lbxContacts.getSelectionModel().selectLast();
        });
        // endregion

        // Start off by selecting the first contact
        lbxContacts.getSelectionModel().selectFirst();
    }
}
