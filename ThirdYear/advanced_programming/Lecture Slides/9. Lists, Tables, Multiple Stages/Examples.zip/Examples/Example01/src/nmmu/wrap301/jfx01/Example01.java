package nmmu.wrap301.jfx01;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Example01 extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    /**
     * Create the scene that will be used to display a single contact
     * @return The scene to display contacts.
     */
    protected Scene createScene() {
        // region Create the container for all the controls
        VBox root = new VBox();
        root.setSpacing(10);
        root.setOpaqueInsets(new Insets(10));
        root.setPadding(new Insets(5));
        // endregion

        // region Create controls to display contact's name
        Label lblName = new Label("Name");
        TextField txtName = new TextField();
        txtName.setId("name"); // id to look up control later
        // endregion

        // region Create controls to display contact's number
        Label lblNumber = new Label("Contact Number");
        TextField txtNumber = new TextField();
        txtNumber.setId("number"); // id to look up control later
        // endregion

        // region Create buttons
        Button btnNew = new Button("New");
        btnNew.setId("new");
        btnNew.setMaxWidth(Double.MAX_VALUE);
        // endregion

        // region Create list view to display all contacts
        // create a list view that can display contacts, with display contents using the toString method
        // of each contact - unless this is overridden
        ListView<Contact> lbxContacts = new ListView<Contact>();
        lbxContacts.setId("contacts");
        // endregion

        root.getChildren().addAll(
                lblName, txtName,
                lblNumber, txtNumber,
                btnNew,
                lbxContacts
        );

        return new Scene(root);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Create scene
        Scene scene = createScene();

        // region Set up controller
        Controller controller = new Controller();
        controller.connectToUI(scene);
        // endregion

        // region Set stage details and start it
        primaryStage.setTitle("Example 1");
        primaryStage.setWidth(300);
        primaryStage.setMinHeight(300);
        primaryStage.setMaxHeight(500);
        primaryStage.setScene(scene);

        // Show stage
        primaryStage.show();
        // endregion
    }
}
