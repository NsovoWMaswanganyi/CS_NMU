package nmmu.wrap301.jfx02;

public class Contact {
    private String name;
    private String contactNumber;

    @Override
    public String toString() {
        return String.format("(%s, %s)", name, contactNumber);
    }

    public String getName() {
        return name;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public Contact(String name, String contactNumber) {
        this.name = name;
        this.contactNumber = contactNumber;
    }
}
