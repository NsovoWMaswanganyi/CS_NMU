package nmmu.wrap301.jfx02;

import javafx.beans.binding.Binding;
import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import java.util.ArrayList;

public class Controller {
    // list of contacts
    private ArrayList<Contact> contacts = new ArrayList<Contact>();

    // wrap array list to make it observable, only interact using this wrapper - do not use contacts
    private ObservableList<Contact> observableContacts = FXCollections.observableArrayList(contacts);

    public ObservableList<Contact> getObservableContacts() {
        return observableContacts;
    }

    public Controller() {
        setupContacts();
    }

    /**
     * Add some dummy contacts
     */
    private void setupContacts() {
        System.out.println("Adding contacts.");

        observableContacts.add(new Contact("Billy Bob", "081-556-1234"));
        observableContacts.add(new Contact("Jane Doe", "082-689-2546"));
        observableContacts.add(new Contact("John Doe", "084-253-1254"));
        observableContacts.add(new Contact("Sammy Sue", "072-123-4567"));
    }

    // references to scene's controls
    private TextField txtName;
    private TextField txtContactNumber;
    private ListView<Contact> lbxContacts;

    /**
     * Bind the UI controls and the controller properties together.
     *
     * @param scene
     */
    public void connectToUI(Scene scene) {
        // obtain references to controls
        System.out.println("Obtaining references to scene controls by id.");

        txtName = (TextField) scene.lookup("#name");
        txtContactNumber = (TextField) scene.lookup("#number");
        lbxContacts = (ListView) scene.lookup("#contacts");

        // set the list contents
        lbxContacts.setItems(observableContacts);

        // create a one directional binding from the selected item's 'name' property to the txtName
        // field's text property
        txtName.textProperty().bind(
                Bindings.selectString(lbxContacts.getSelectionModel().selectedItemProperty(), "name")
        );

        // ditto for the contact number
        txtContactNumber.textProperty().bind(
                Bindings.selectString(lbxContacts.getSelectionModel().selectedItemProperty(),"contactNumber")
        );


        // start off by selecting the first contact
        lbxContacts.getSelectionModel().selectFirst();
    }
}
