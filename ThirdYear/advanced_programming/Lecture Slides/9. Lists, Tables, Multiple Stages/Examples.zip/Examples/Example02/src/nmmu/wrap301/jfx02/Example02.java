package nmmu.wrap301.jfx02;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Example02 extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    /**
     * Create the scene that will be used to display a single contact
     *
     * @return
     */
    protected Scene createScene() {
        // container for controls
        VBox root = new VBox();
        root.setSpacing(10);
        root.setOpaqueInsets(new Insets(10, 10, 10, 10));
        root.setFillWidth(true);

        // create controls to display contact's name
        Label lblName = new Label("Name");
        TextField txtName = new TextField();
        txtName.setId("name"); // id to look up control later

        // create controls to display contact's number
        Label lblNumber = new Label("Contact Number");
        TextField txtNumber = new TextField();
        txtNumber.setId("number"); // id to look up control later

        // create a list view that can display contacts, with display contents using the toString method
        // of each contact - unless this is overridden
        ListView<Contact> lbxContacts = new ListView<Contact>();
        lbxContacts.setId("contacts");

        root.getChildren().addAll(
                lblName, txtName,
                lblNumber, txtNumber,
                lbxContacts
        );

        return new Scene(root);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        // create scene
        Scene scene = createScene();

        // create controller
        Controller controller = new Controller();

        // connect controller to scene
        controller.connectToUI(scene);

        // set stage details
        primaryStage.setTitle("Example 2");
        primaryStage.setWidth(300);
        primaryStage.setMinHeight(400);
        primaryStage.setScene(scene);

        // show stage
        primaryStage.show();

    }
}
