package nmu.wrpv301.jfx03b;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Contact {
    // region Properties that will be used to connect to the UI
    private StringProperty firstName = new SimpleStringProperty();
    private StringProperty surname = new SimpleStringProperty();
    private StringProperty contactNumber = new SimpleStringProperty();
    // endregion

    // The ListView uses the toString method to decide what to display in a line.
    @Override
    public String toString() {
        return String.format("(%s, %s, %s)", surname.getValue(), firstName.getValue(), contactNumber.getValue());
    }

    // region Getters for the properties - to prevent other developers from accidently overwriting a property.
    public StringProperty surnameProperty() {
        return surname;
    }
    public StringProperty firstNameProperty() {
        return firstName;
    }
    public StringProperty contactNumberProperty() {
        return contactNumber;
    }
    // endregion

    public Contact(String firstName, String surname, String contactNumber) {
        this.surname.set(surname);
        this.firstName.set(firstName);
        this.contactNumber.set(contactNumber);
    }
}
