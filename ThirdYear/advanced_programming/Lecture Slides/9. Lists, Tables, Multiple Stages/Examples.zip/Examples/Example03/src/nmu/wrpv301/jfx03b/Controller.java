package nmu.wrpv301.jfx03b;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;

public class Controller {
    private ObservableList<Contact> contacts;

    // region Cached references.
    private Scene scene;
    private TableView<Contact> tblContacts;
    private Button btnNew;
    private Button btnModify;
    private Button btnDelete;
    private CheckBox cbxEditable;

    private TableColumn colFirstName;
    private TableColumn colSurname;
    private TableColumn colContactNumber;
    // endregion

    public Controller(Scene scene) {
        this.scene = scene;

        setupContacts();
        cacheReferences();
        setupTable();
        setTableEditable();
        attachEventHandlers();
    }

    private void setupContacts() {
        // Create the observable list.
        contacts = FXCollections.observableArrayList();

        // Set extractor?

        // Add some dummy values.
        contacts.addAll(
                new Contact("Joe", "Soap", "1234-5678-987"),
                new Contact("Jane", "Doe", "2345-6857-865"),
                new Contact("Billy", "Bob", "9856-8547-521"));
    }

    private void cacheReferences() {
        tblContacts = (TableView<Contact>) scene.lookup("#table");
        btnNew = (Button) scene.lookup("#new");
        btnModify = (Button) scene.lookup("#modify");
        btnDelete = (Button) scene.lookup("#delete");
        cbxEditable = (CheckBox) scene.lookup("#editable");
    }

    private void setupTable() {
        // region Create a column PER property you want displayed in the TableView.
        colFirstName = new TableColumn("First Name");
        colFirstName.setCellValueFactory(
                new PropertyValueFactory<Contact, String>("firstName"));

        colSurname = new TableColumn("Surname");
        colSurname.setCellValueFactory(
                new PropertyValueFactory<Contact, String>("surname"));

        colContactNumber = new TableColumn("Contact Number");
        colContactNumber.setCellValueFactory(
                new PropertyValueFactory<Contact, String>("contactNumber"));
        // endregion

        // Now add all the columns to the TableView.
        tblContacts.getColumns().addAll(colSurname, colFirstName, colContactNumber);

        // Set the list the TableView is to display.
        tblContacts.setItems(contacts);
    }

    private void setTableEditable() {
        // region Indicate PER column, what control to use and how to set the value.
        colSurname.setCellFactory(TextFieldTableCell.forTableColumn());
        colSurname.setOnEditCommit(event -> {
            // Typecast event into something more usable.
            TableColumn.CellEditEvent<Contact, String> e = (TableColumn.CellEditEvent<Contact, String>) event;

            // Get specific contact that was being edited.
            Contact contact = e.getTableView().getSelectionModel().getSelectedItem();
            // Change its surname to that in the TextField.
            contact.surnameProperty().set(e.getNewValue());
        });

        colFirstName.setCellFactory(TextFieldTableCell.forTableColumn());
        colFirstName.setOnEditCommit(event -> {
            // Typecast event into something more usable.
            TableColumn.CellEditEvent<Contact, String> e = (TableColumn.CellEditEvent<Contact, String>) event;

            // Get specific contact that was being edited.
            Contact contact = e.getTableView().getSelectionModel().getSelectedItem();
            // Change its surname to that in the TextField.
            contact.firstNameProperty().set(e.getNewValue());
        });

        colContactNumber.setCellFactory(TextFieldTableCell.forTableColumn());
        colContactNumber.setOnEditCommit(event -> {
            // Typecast event into something more usable.
            TableColumn.CellEditEvent<Contact, String> e = (TableColumn.CellEditEvent<Contact, String>) event;

            // Get specific contact that was being edited.
            Contact contact = e.getTableView().getSelectionModel().getSelectedItem();
            // Change its surname to that in the TextField.
            contact.contactNumberProperty().set(e.getNewValue());
        });
        // endregion

        // Initially not editable until checkbox checked.
        tblContacts.setEditable(false);
    }

    private void attachEventHandlers() {
        btnNew.setOnAction(event ->
                contacts.add(new Contact("?","?","?")));

        btnModify.setOnAction(event ->
                contacts.get(0).surnameProperty().set("Whodis"));

        btnDelete.setOnAction(event ->
                contacts.remove(tblContacts.getSelectionModel().getSelectedItem()));

        cbxEditable.setOnAction(event -> tblContacts.setEditable(cbxEditable.isSelected()));

        tblContacts.getSelectionModel().selectedItemProperty().addListener((observable,oldValue,newValue) ->
            System.out.printf("Contact selected = %s\n", newValue));
    }
}
