package nmu.wrpv301.jfx03b;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Example03 extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    private Scene createScene() {
        VBox root = new VBox();
        root.setPadding(new Insets(5));
        root.setSpacing(5);

        TableView<Contact> tblContacts = new TableView<>();
        tblContacts.setId("table");

        Button btnNew = new Button("New");
        btnNew.setMaxWidth(Double.MAX_VALUE);
        btnNew.setId("new");

        Button btnModify = new Button("Modify 1st");
        btnModify.setMaxWidth(Double.MAX_VALUE);
        btnModify.setId("modify");

        Button btnDelete = new Button("Delete");
        btnDelete.setMaxWidth(Double.MAX_VALUE);
        btnDelete.setId("delete");

        CheckBox cbxEditable = new CheckBox("Editable");
        cbxEditable.setMaxWidth(Double.MAX_VALUE);
        cbxEditable.setId("editable");

        root.getChildren().addAll(
                new Label("Contacts"),
                tblContacts,
                btnNew,
                btnModify,
                btnDelete,
                cbxEditable
        );

        return new Scene(root);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Create View.
        Scene scene = createScene();

        // Create controller.
        Controller controller = new Controller(scene);

        // region Set up stage and show it.
        primaryStage.setTitle("Example 3");
        primaryStage.setScene(scene);
        primaryStage.setWidth(350);
        primaryStage.setHeight(400);
        primaryStage.show();
        // endregion
    }
}

