package nmmu.wrap301.jfx04;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class Controller {
    private ObservableList<Person> people = FXCollections.observableArrayList();

    public Controller(Scene scene, Stage editing) {
        setupPeople();
        linkToScene(scene, editing);
    }

    private void setupPeople() {
        people.addAll(
                new Person("Billy", "Bob", 17),
                new Person("Jane", "Doe", 20),
                new Person("John", "Doe", 19),
                new Person("Sammy", "Sue", 15)
        );
    }

    // Want to remember old position of pop-up window.
    private double oldX = 0, oldY = 0;

    private void linkToScene(Scene scene, Stage editing) {
        // region Set up TableView
        // Obtain reference to table view
        TableView<Person> tblPeople = (TableView<Person>) scene.lookup("#table");

        // Create columns and specify the properties they will be binding too
        TableColumn colSurname = new TableColumn("Surname");
        colSurname.setCellValueFactory(new PropertyValueFactory("surname"));
        colSurname.setPrefWidth(100);

        TableColumn colFirstName = new TableColumn("First Name");
        colFirstName.setCellValueFactory(new PropertyValueFactory("firstName"));
        colFirstName.setPrefWidth(100);

        TableColumn colAge = new TableColumn("Age");
        colAge.setCellValueFactory(new PropertyValueFactory("age"));
        colAge.setPrefWidth(100);

        // Add columns to table
        tblPeople.getColumns().addAll(
                colSurname,
                colFirstName,
                colAge
        );

        // Set data for table
        tblPeople.setItems(people);
        // endregion

        // add new person
        Button btnNew = (Button) scene.lookup("#new");
        btnNew.setOnAction(event -> {
            // Initialise
            TextField txtFirstName = (TextField) editing.getScene().lookup("#firstName");
            TextField txtSurname = (TextField) editing.getScene().lookup("#surname");
            TextField txtAge = (TextField) editing.getScene().lookup("#age");

            txtFirstName.textProperty().set("");
            txtSurname.textProperty().set("");
            txtAge.textProperty().setValue("0");

            // Restore old position if had one.
            if(oldX != 0) {
                editing.setX(oldX);
                editing.setY(oldY);
            }

            // Show and wait - waits for stage to close.
            editing.showAndWait();

            // Remember current position as the "new" old position.
            oldX = editing.getX();
            oldY = editing.getY();

            // Retrieve values
            Person person = new Person(
                    txtFirstName.textProperty().get(),
                    txtSurname.textProperty().get(),
                    Integer.parseInt(txtAge.textProperty().get())
            );

            // Add new person to list
            people.add(person);
        });

        Button btnDelete = (Button) scene.lookup("#delete");
        btnDelete.setOnAction(event -> {
            Person selected = tblPeople.getSelectionModel().selectedItemProperty().getValue();
            if(selected != null) {
                people.remove(selected);
            }
        });
    }
}
