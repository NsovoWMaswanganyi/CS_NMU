package nmmu.wrap301.jfx04;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Example04 extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    public Scene createMainScene() {
        VBox root = new VBox();
        root.setFillWidth(true);
        root.setSpacing(5);
        root.setPadding(new Insets(5));

        TableView<Person> tblPeople = new TableView<>();
        tblPeople.setId("table");

        Button btnNew = new Button("New");
        btnNew.setMaxWidth(Double.MAX_VALUE);
        btnNew.setId("new");

        Button btnDelete = new Button("Delete");
        btnDelete.setMaxWidth(Double.MAX_VALUE);
        btnDelete.setId("delete");

        root.getChildren().addAll(
                new Label("People"),
                tblPeople,
                btnNew,
                btnDelete
        );

        return new Scene(root);
    }

    public Stage createEditingStage(Stage owner) {
        Stage stage = new Stage();

        VBox root = new VBox();
        root.setSpacing(10);
        root.setFillWidth(true);
        root.setPadding(new Insets(5));

        TextField txtFirstName = new TextField();
        txtFirstName.setId("firstName");
        TextField txtSurname = new TextField();
        txtSurname.setId("surname");
        TextField txtAge = new TextField();
        txtAge.setId("age");

        Button btnOK = new Button("OK");
        btnOK.setId("ok");
        btnOK.setMaxWidth(Double.MAX_VALUE);

        root.getChildren().addAll(
                new Label("First Name"), txtFirstName,
                new Label("Surname"), txtSurname,
                new Label("Age"), txtAge,
                btnOK
        );

        // bit of a cheat, but really too simple to create a new controller
        btnOK.setOnAction(event -> stage.hide());

        stage.setScene(new Scene(root));

        // set stage details
        stage.setTitle("New Person");

        // only has close button and cannot be resized
        stage.initStyle(StageStyle.UTILITY);
        stage.setResizable(false);

        // rest of application cannot be interacted with until this stage is closed
        stage.initModality(Modality.APPLICATION_MODAL);

        // this stage belongs to another, i.e. will close if the owner does
        stage.initOwner(owner);

        return stage;
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        Scene scene = createMainScene();
        Stage editingStage = createEditingStage(primaryStage);

        Controller controller = new Controller(scene, editingStage);

        primaryStage.setTitle("Example 4");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}