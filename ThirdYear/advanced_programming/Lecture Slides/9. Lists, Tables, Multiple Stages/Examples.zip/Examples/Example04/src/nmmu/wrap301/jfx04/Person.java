package nmmu.wrap301.jfx04;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Person {
    private StringProperty firstName = new SimpleStringProperty();
    private StringProperty surname = new SimpleStringProperty();
    private IntegerProperty age = new SimpleIntegerProperty();

    public Person(String firstName, String surname, int age) {
        this.firstName.set(firstName);
        this.surname.set(surname);
        this.age.set(age);
    }

    @Override
    public String toString() {
        return String.format("(%s, %s, %s)", surname.get(), firstName.get(), age.get());
    }

    public void setFirstName(String firstName) {
        this.firstName.set(firstName);
    }

    public String getFirstName() {
        return firstName.get();
    }

    public StringProperty firstNameProperty() {
        return firstName;
    }

    public void setSurname(String surname) {
        this.surname.set(surname);
    }

    public String getSurname() {
        return surname.get();
    }

    public StringProperty surnameProperty() {
        return surname;
    }

    public void setAge(int age) {
        this.age.set(age);
    }

    public int getAge() {
        return age.get();
    }

    public IntegerProperty ageProperty() {
        return age;
    }
}
